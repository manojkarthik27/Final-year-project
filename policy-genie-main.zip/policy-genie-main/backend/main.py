from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import datetime, timedelta
from typing import List, Optional
import uuid

from config import get_settings
from database import init_db, get_db, User, Prediction, InsurancePartner, ClickEvent
from auth import (
    get_password_hash, verify_password, create_access_token,
    get_current_user, get_current_admin, get_optional_user
)
from schemas import (
    UserCreate, UserLogin, UserResponse, TokenResponse,
    HealthAssessmentData, PredictionResponse,
    PartnerCreate, PartnerUpdate, PartnerResponse,
    ClickTrack, AnalyticsSummary, TopPartner, DailyStat, RiskDistribution
)
from risk_engine import (
    calculate_risk_score, get_risk_level,
    generate_recommendations, generate_policy_recommendations
)

settings = get_settings()
app = FastAPI(title="Health Insight Pro API", version="1.0.0")

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify your frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup():
    init_db()
    # Create default admin if not exists
    db = next(get_db())
    admin = db.query(User).filter(User.email == settings.ADMIN_EMAIL).first()
    if not admin:
        admin = User(
            id=str(uuid.uuid4()),
            email=settings.ADMIN_EMAIL,
            name="Admin",
            hashed_password=get_password_hash(settings.ADMIN_PASSWORD),
            role="admin"
        )
        db.add(admin)
        
        # Add sample partners
        sample_partners = [
            InsurancePartner(
                id=str(uuid.uuid4()),
                name="PolicyBazaar",
                logo="https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=100&h=100&fit=crop",
                website="https://policybazaar.com",
                affiliate_url="https://policybazaar.com?ref=healthinsight",
                affiliate_code="HEALTH2024",
                description="India's largest insurance aggregator with 50+ insurers",
                rating=4.5,
                priority=1
            ),
            InsurancePartner(
                id=str(uuid.uuid4()),
                name="Coverfox",
                logo="https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=100&h=100&fit=crop",
                website="https://coverfox.com",
                affiliate_url="https://coverfox.com?ref=healthinsight",
                affiliate_code="CF2024",
                description="Compare and buy insurance online instantly",
                rating=4.3,
                priority=2
            ),
            InsurancePartner(
                id=str(uuid.uuid4()),
                name="TATA AIG",
                logo="https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=100&h=100&fit=crop",
                website="https://tataaig.com",
                affiliate_url="https://tataaig.com?ref=healthinsight",
                affiliate_code="TATA2024",
                description="Trusted insurance from the TATA Group",
                rating=4.6,
                priority=3
            ),
            InsurancePartner(
                id=str(uuid.uuid4()),
                name="HDFC ERGO",
                logo="https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=100&h=100&fit=crop",
                website="https://hdfcergo.com",
                affiliate_url="https://hdfcergo.com?ref=healthinsight",
                affiliate_code="HDFC2024",
                description="Comprehensive health coverage with quick claims",
                rating=4.5,
                priority=4
            ),
        ]
        for partner in sample_partners:
            db.add(partner)
        
        db.commit()
        print(f"Created admin user: {settings.ADMIN_EMAIL}")


# ============= AUTH ROUTES =============

@app.post("/api/auth/register", response_model=TokenResponse)
def register(user_data: UserCreate, db: Session = Depends(get_db)):
    existing = db.query(User).filter(User.email == user_data.email).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )
    
    user = User(
        id=str(uuid.uuid4()),
        email=user_data.email,
        name=user_data.name,
        hashed_password=get_password_hash(user_data.password),
        role="user"
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    
    token = create_access_token(data={"sub": user.id})
    
    return TokenResponse(
        user=UserResponse(
            id=user.id,
            email=user.email,
            name=user.name,
            role=user.role,
            createdAt=user.created_at.isoformat()
        ),
        token=token
    )


@app.post("/api/auth/login", response_model=TokenResponse)
def login(credentials: UserLogin, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == credentials.email).first()
    if not user or not verify_password(credentials.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password"
        )
    
    token = create_access_token(data={"sub": user.id})
    
    return TokenResponse(
        user=UserResponse(
            id=user.id,
            email=user.email,
            name=user.name,
            role=user.role,
            createdAt=user.created_at.isoformat()
        ),
        token=token
    )


@app.get("/api/auth/me", response_model=UserResponse)
def get_me(current_user: User = Depends(get_current_user)):
    return UserResponse(
        id=current_user.id,
        email=current_user.email,
        name=current_user.name,
        role=current_user.role,
        createdAt=current_user.created_at.isoformat()
    )


# ============= ASSESSMENT ROUTES =============

@app.post("/api/assessment/submit", response_model=PredictionResponse)
def submit_assessment(
    data: HealthAssessmentData,
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_optional_user)
):
    risk_score = calculate_risk_score(data)
    risk_level = get_risk_level(risk_score.overall)
    recommendations = generate_recommendations(risk_score, data)
    
    partners = db.query(InsurancePartner).filter(InsurancePartner.is_active == True).order_by(InsurancePartner.priority).all()
    policy_recommendations = generate_policy_recommendations(risk_score, partners)
    
    prediction_id = str(uuid.uuid4())
    user_id = current_user.id if current_user else "guest"
    
    if current_user:
        prediction = Prediction(
            id=prediction_id,
            user_id=user_id,
            assessment_data=data.model_dump(),
            risk_score=risk_score.model_dump(),
            risk_level=risk_level,
            recommendations=recommendations
        )
        db.add(prediction)
        db.commit()
    
    return PredictionResponse(
        id=prediction_id,
        userId=user_id,
        assessmentData=data,
        riskScore=risk_score,
        riskLevel=risk_level,
        recommendations=recommendations,
        createdAt=datetime.utcnow().isoformat(),
        policyRecommendations=policy_recommendations
    )


@app.get("/api/assessment/prediction/{prediction_id}", response_model=PredictionResponse)
def get_prediction(
    prediction_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    prediction = db.query(Prediction).filter(
        Prediction.id == prediction_id,
        Prediction.user_id == current_user.id
    ).first()
    
    if not prediction:
        raise HTTPException(status_code=404, detail="Prediction not found")
    
    partners = db.query(InsurancePartner).filter(InsurancePartner.is_active == True).order_by(InsurancePartner.priority).all()
    risk_score_dict = prediction.risk_score
    from schemas import RiskScore
    risk_score = RiskScore(**risk_score_dict)
    policy_recommendations = generate_policy_recommendations(risk_score, partners)
    
    return PredictionResponse(
        id=prediction.id,
        userId=prediction.user_id,
        assessmentData=HealthAssessmentData(**prediction.assessment_data),
        riskScore=risk_score,
        riskLevel=prediction.risk_level,
        recommendations=prediction.recommendations,
        createdAt=prediction.created_at.isoformat(),
        policyRecommendations=policy_recommendations
    )


@app.get("/api/assessment/user-predictions", response_model=List[PredictionResponse])
def get_user_predictions(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    predictions = db.query(Prediction).filter(
        Prediction.user_id == current_user.id
    ).order_by(Prediction.created_at.desc()).limit(10).all()
    
    partners = db.query(InsurancePartner).filter(InsurancePartner.is_active == True).order_by(InsurancePartner.priority).all()
    
    results = []
    for prediction in predictions:
        from schemas import RiskScore
        risk_score = RiskScore(**prediction.risk_score)
        policy_recommendations = generate_policy_recommendations(risk_score, partners)
        
        results.append(PredictionResponse(
            id=prediction.id,
            userId=prediction.user_id,
            assessmentData=HealthAssessmentData(**prediction.assessment_data),
            riskScore=risk_score,
            riskLevel=prediction.risk_level,
            recommendations=prediction.recommendations,
            createdAt=prediction.created_at.isoformat(),
            policyRecommendations=policy_recommendations
        ))
    
    return results


# ============= PARTNER ROUTES =============

@app.get("/api/partners", response_model=List[PartnerResponse])
def get_partners(db: Session = Depends(get_db)):
    partners = db.query(InsurancePartner).order_by(InsurancePartner.priority).all()
    return [
        PartnerResponse(
            id=p.id,
            name=p.name,
            logo=p.logo,
            website=p.website,
            affiliateUrl=p.affiliate_url,
            affiliateCode=p.affiliate_code,
            description=p.description,
            rating=p.rating,
            isActive=p.is_active,
            priority=p.priority,
            createdAt=p.created_at.isoformat(),
            updatedAt=p.updated_at.isoformat()
        )
        for p in partners
    ]


@app.post("/api/partners", response_model=PartnerResponse)
def create_partner(
    data: PartnerCreate,
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_admin)
):
    partner = InsurancePartner(
        id=str(uuid.uuid4()),
        name=data.name,
        logo=data.logo,
        website=data.website,
        affiliate_url=data.affiliateUrl,
        affiliate_code=data.affiliateCode,
        description=data.description,
        rating=data.rating,
        is_active=data.isActive,
        priority=data.priority
    )
    db.add(partner)
    db.commit()
    db.refresh(partner)
    
    return PartnerResponse(
        id=partner.id,
        name=partner.name,
        logo=partner.logo,
        website=partner.website,
        affiliateUrl=partner.affiliate_url,
        affiliateCode=partner.affiliate_code,
        description=partner.description,
        rating=partner.rating,
        isActive=partner.is_active,
        priority=partner.priority,
        createdAt=partner.created_at.isoformat(),
        updatedAt=partner.updated_at.isoformat()
    )


@app.put("/api/partners/{partner_id}", response_model=PartnerResponse)
def update_partner(
    partner_id: str,
    data: PartnerUpdate,
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_admin)
):
    partner = db.query(InsurancePartner).filter(InsurancePartner.id == partner_id).first()
    if not partner:
        raise HTTPException(status_code=404, detail="Partner not found")
    
    update_data = data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        if key == "affiliateUrl":
            setattr(partner, "affiliate_url", value)
        elif key == "affiliateCode":
            setattr(partner, "affiliate_code", value)
        elif key == "isActive":
            setattr(partner, "is_active", value)
        else:
            setattr(partner, key, value)
    
    db.commit()
    db.refresh(partner)
    
    return PartnerResponse(
        id=partner.id,
        name=partner.name,
        logo=partner.logo,
        website=partner.website,
        affiliateUrl=partner.affiliate_url,
        affiliateCode=partner.affiliate_code,
        description=partner.description,
        rating=partner.rating,
        isActive=partner.is_active,
        priority=partner.priority,
        createdAt=partner.created_at.isoformat(),
        updatedAt=partner.updated_at.isoformat()
    )


@app.delete("/api/partners/{partner_id}")
def delete_partner(
    partner_id: str,
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_admin)
):
    partner = db.query(InsurancePartner).filter(InsurancePartner.id == partner_id).first()
    if not partner:
        raise HTTPException(status_code=404, detail="Partner not found")
    
    db.delete(partner)
    db.commit()
    return {"message": "Partner deleted"}


# ============= ANALYTICS ROUTES =============

@app.post("/api/analytics/click")
def track_click(
    data: ClickTrack,
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_optional_user)
):
    click = ClickEvent(
        id=str(uuid.uuid4()),
        user_id=current_user.id if current_user else None,
        partner_id=data.partnerId,
        policy_id=data.policyId,
        source=data.source
    )
    db.add(click)
    db.commit()
    return {"message": "Click tracked"}


@app.get("/api/analytics", response_model=AnalyticsSummary)
def get_analytics(
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_admin),
    start_date: Optional[str] = None,
    end_date: Optional[str] = None
):
    # Total counts
    total_predictions = db.query(Prediction).count()
    total_clicks = db.query(ClickEvent).count()
    total_conversions = db.query(ClickEvent).filter(ClickEvent.converted == True).count()
    conversion_rate = (total_conversions / total_clicks * 100) if total_clicks > 0 else 0
    
    # Average risk score
    predictions = db.query(Prediction).all()
    avg_risk = sum(p.risk_score.get("overall", 0) for p in predictions) / len(predictions) if predictions else 0
    
    # Risk distribution
    risk_dist = {"low": 0, "moderate": 0, "high": 0, "critical": 0}
    for p in predictions:
        level = p.risk_level
        if level in risk_dist:
            risk_dist[level] += 1
    
    # Top partners
    partner_clicks = db.query(
        ClickEvent.partner_id,
        func.count(ClickEvent.id).label("clicks"),
        func.sum(func.cast(ClickEvent.converted, db.bind.dialect.name == 'sqlite' and 'INTEGER' or 'INT')).label("conversions")
    ).group_by(ClickEvent.partner_id).all()
    
    top_partners = []
    for partner_id, clicks, conversions in partner_clicks:
        partner = db.query(InsurancePartner).filter(InsurancePartner.id == partner_id).first()
        if partner:
            top_partners.append(TopPartner(
                partnerId=partner_id,
                partnerName=partner.name,
                clicks=clicks,
                conversions=int(conversions or 0)
            ))
    top_partners.sort(key=lambda x: x.clicks, reverse=True)
    
    # Daily stats (last 30 days)
    daily_stats = []
    for i in range(30):
        date = datetime.utcnow() - timedelta(days=29-i)
        date_str = date.strftime("%Y-%m-%d")
        
        day_predictions = db.query(Prediction).filter(
            func.date(Prediction.created_at) == date.date()
        ).count()
        
        day_clicks = db.query(ClickEvent).filter(
            func.date(ClickEvent.timestamp) == date.date()
        ).count()
        
        day_conversions = db.query(ClickEvent).filter(
            func.date(ClickEvent.timestamp) == date.date(),
            ClickEvent.converted == True
        ).count()
        
        daily_stats.append(DailyStat(
            date=date_str,
            predictions=day_predictions,
            clicks=day_clicks,
            conversions=day_conversions
        ))
    
    return AnalyticsSummary(
        totalPredictions=total_predictions,
        totalClicks=total_clicks,
        totalConversions=total_conversions,
        conversionRate=round(conversion_rate, 2),
        averageRiskScore=round(avg_risk, 1),
        riskDistribution=RiskDistribution(**risk_dist),
        topPartners=top_partners[:5],
        dailyStats=daily_stats
    )


# ============= ADMIN ROUTES =============

@app.get("/api/admin/stats", response_model=AnalyticsSummary)
def get_admin_stats(
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_admin)
):
    return get_analytics(db=db, admin=admin)


@app.get("/api/admin/users", response_model=List[UserResponse])
def get_users(
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_admin)
):
    users = db.query(User).order_by(User.created_at.desc()).all()
    return [
        UserResponse(
            id=u.id,
            email=u.email,
            name=u.name,
            role=u.role,
            createdAt=u.created_at.isoformat()
        )
        for u in users
    ]


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
