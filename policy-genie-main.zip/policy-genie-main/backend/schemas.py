from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum


# Enums
class Gender(str, Enum):
    MALE = "male"
    FEMALE = "female"
    OTHER = "other"


class SmokingStatus(str, Enum):
    NEVER = "never"
    FORMER = "former"
    CURRENT = "current"


class AlcoholConsumption(str, Enum):
    NONE = "none"
    OCCASIONAL = "occasional"
    MODERATE = "moderate"
    HEAVY = "heavy"


class ExerciseFrequency(str, Enum):
    SEDENTARY = "sedentary"
    LIGHT = "light"
    MODERATE = "moderate"
    ACTIVE = "active"
    VERY_ACTIVE = "very_active"


class DietType(str, Enum):
    BALANCED = "balanced"
    VEGETARIAN = "vegetarian"
    VEGAN = "vegan"
    KETO = "keto"
    POOR = "poor"


class StressLevel(str, Enum):
    LOW = "low"
    MODERATE = "moderate"
    HIGH = "high"
    VERY_HIGH = "very_high"


class RiskLevel(str, Enum):
    LOW = "low"
    MODERATE = "moderate"
    HIGH = "high"
    CRITICAL = "critical"


class UserRole(str, Enum):
    USER = "user"
    ADMIN = "admin"


# Auth Schemas
class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)
    name: str = Field(min_length=2, max_length=100)


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserResponse(BaseModel):
    id: str
    email: str
    name: str
    role: str
    createdAt: str

    class Config:
        from_attributes = True


class TokenResponse(BaseModel):
    user: UserResponse
    token: str


# Health Assessment Schemas
class PersonalInfo(BaseModel):
    age: int = Field(ge=1, le=120)
    gender: Gender
    location: str
    occupation: str
    annualIncome: int = Field(ge=0)


class BodyMetrics(BaseModel):
    height: int = Field(ge=50, le=300)  # cm
    weight: int = Field(ge=20, le=500)  # kg
    bmi: float


class LifestyleHabits(BaseModel):
    smokingStatus: SmokingStatus
    alcoholConsumption: AlcoholConsumption
    exerciseFrequency: ExerciseFrequency
    dietType: DietType
    sleepHours: float = Field(ge=0, le=24)
    stressLevel: StressLevel


class MedicalHistory(BaseModel):
    chronicConditions: List[str] = []
    previousSurgeries: List[str] = []
    hospitalizations: int = Field(ge=0)
    currentMedications: List[str] = []
    allergies: List[str] = []


class FamilyHistory(BaseModel):
    heartDisease: bool = False
    diabetes: bool = False
    cancer: bool = False
    hypertension: bool = False
    mentalHealth: bool = False
    other: List[str] = []


class HealthAssessmentData(BaseModel):
    personalInfo: PersonalInfo
    bodyMetrics: BodyMetrics
    lifestyleHabits: LifestyleHabits
    medicalHistory: MedicalHistory
    familyHistory: FamilyHistory


class RiskScore(BaseModel):
    overall: int
    cardiovascular: int
    diabetes: int
    lifestyle: int
    genetic: int


class PolicyRecommendation(BaseModel):
    id: str
    partnerId: str
    partnerName: str
    partnerLogo: str
    policyName: str
    coverageAmount: int
    premiumEstimate: int
    premiumFrequency: str
    matchScore: int
    keyBenefits: List[str]
    exclusions: List[str]
    claimSettlementRatio: int
    affiliateUrl: str


class PredictionResponse(BaseModel):
    id: str
    userId: str
    assessmentData: HealthAssessmentData
    riskScore: RiskScore
    riskLevel: RiskLevel
    recommendations: List[str]
    createdAt: str
    policyRecommendations: List[PolicyRecommendation]


# Partner Schemas
class PartnerCreate(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    logo: Optional[str] = None
    website: Optional[str] = None
    affiliateUrl: str
    affiliateCode: Optional[str] = None
    description: Optional[str] = None
    rating: float = Field(ge=0, le=5, default=4.0)
    isActive: bool = True
    priority: int = 0


class PartnerUpdate(BaseModel):
    name: Optional[str] = None
    logo: Optional[str] = None
    website: Optional[str] = None
    affiliateUrl: Optional[str] = None
    affiliateCode: Optional[str] = None
    description: Optional[str] = None
    rating: Optional[float] = None
    isActive: Optional[bool] = None
    priority: Optional[int] = None


class PartnerResponse(BaseModel):
    id: str
    name: str
    logo: Optional[str]
    website: Optional[str]
    affiliateUrl: str
    affiliateCode: Optional[str]
    description: Optional[str]
    rating: float
    isActive: bool
    priority: int
    createdAt: str
    updatedAt: str

    class Config:
        from_attributes = True


# Analytics Schemas
class ClickTrack(BaseModel):
    partnerId: str
    policyId: str
    source: str


class TopPartner(BaseModel):
    partnerId: str
    partnerName: str
    clicks: int
    conversions: int


class DailyStat(BaseModel):
    date: str
    predictions: int
    clicks: int
    conversions: int


class RiskDistribution(BaseModel):
    low: int
    moderate: int
    high: int
    critical: int


class AnalyticsSummary(BaseModel):
    totalPredictions: int
    totalClicks: int
    totalConversions: int
    conversionRate: float
    averageRiskScore: float
    riskDistribution: RiskDistribution
    topPartners: List[TopPartner]
    dailyStats: List[DailyStat]
