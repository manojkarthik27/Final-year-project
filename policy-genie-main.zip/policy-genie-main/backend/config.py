from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    SECRET_KEY: str = "your-super-secret-key-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days
    DATABASE_URL: str = "sqlite:///./health_insight.db"
    ADMIN_EMAIL: str = "suhasbs9353@gmail.com"
    ADMIN_PASSWORD: str = "Suhasbs1807@"

    class Config:
        env_file = ".env"


@lru_cache()
def get_settings():
    return Settings()
