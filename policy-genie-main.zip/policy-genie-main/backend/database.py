from sqlalchemy import create_engine, Column, String, Integer, Float, Boolean, DateTime, Text, Enum, ForeignKey, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
import enum

from config import get_settings

settings = get_settings()

engine = create_engine(
    settings.DATABASE_URL,
    connect_args={"check_same_thread": False} if "sqlite" in settings.DATABASE_URL else {}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class UserRole(str, enum.Enum):
    USER = "user"
    ADMIN = "admin"


class User(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True)
    email = Column(String, unique=True, index=True, nullable=False)
    name = Column(String, nullable=False)
    hashed_password = Column(String, nullable=False)
    role = Column(String, default=UserRole.USER.value)
    created_at = Column(DateTime, default=datetime.utcnow)

    predictions = relationship("Prediction", back_populates="user")
    clicks = relationship("ClickEvent", back_populates="user")


class Prediction(Base):
    __tablename__ = "predictions"

    id = Column(String, primary_key=True)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    assessment_data = Column(JSON, nullable=False)
    risk_score = Column(JSON, nullable=False)
    risk_level = Column(String, nullable=False)
    recommendations = Column(JSON, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="predictions")


class InsurancePartner(Base):
    __tablename__ = "insurance_partners"

    id = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    logo = Column(String)
    website = Column(String)
    affiliate_url = Column(String, nullable=False)
    affiliate_code = Column(String)
    description = Column(Text)
    rating = Column(Float, default=4.0)
    is_active = Column(Boolean, default=True)
    priority = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    clicks = relationship("ClickEvent", back_populates="partner")


class ClickEvent(Base):
    __tablename__ = "click_events"

    id = Column(String, primary_key=True)
    user_id = Column(String, ForeignKey("users.id"), nullable=True)
    partner_id = Column(String, ForeignKey("insurance_partners.id"), nullable=False)
    policy_id = Column(String)
    source = Column(String)
    converted = Column(Boolean, default=False)
    timestamp = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="clicks")
    partner = relationship("InsurancePartner", back_populates="clicks")


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    Base.metadata.create_all(bind=engine)
