from typing import List
from schemas import RiskScore, PolicyRecommendation, HealthAssessmentData


def calculate_risk_score(data: HealthAssessmentData) -> RiskScore:
    """Calculate health risk scores based on assessment data."""
    cardiovascular = 0
    diabetes = 0
    lifestyle = 0
    genetic = 0

    personal = data.personalInfo
    body = data.bodyMetrics
    habits = data.lifestyleHabits
    medical = data.medicalHistory
    family = data.familyHistory

    # Age factor
    if personal.age > 50:
        cardiovascular += 20
    elif personal.age > 40:
        cardiovascular += 10
    if personal.age > 45:
        diabetes += 15

    # BMI factor
    if body.bmi >= 30:
        cardiovascular += 25
        diabetes += 30
        lifestyle += 20
    elif body.bmi >= 25:
        cardiovascular += 15
        diabetes += 20
        lifestyle += 10
    elif body.bmi < 18.5:
        lifestyle += 15

    # Smoking factor
    if habits.smokingStatus == "current":
        cardiovascular += 30
        lifestyle += 25
    elif habits.smokingStatus == "former":
        cardiovascular += 10
        lifestyle += 5

    # Alcohol factor
    if habits.alcoholConsumption == "heavy":
        lifestyle += 25
        cardiovascular += 15
    elif habits.alcoholConsumption == "moderate":
        lifestyle += 10

    # Exercise factor
    if habits.exerciseFrequency == "sedentary":
        cardiovascular += 20
        diabetes += 15
        lifestyle += 20
    elif habits.exerciseFrequency in ["active", "very_active"]:
        cardiovascular -= 10
        diabetes -= 10
        lifestyle -= 10

    # Sleep factor
    if habits.sleepHours < 6 or habits.sleepHours > 9:
        lifestyle += 15
        cardiovascular += 10

    # Stress factor
    if habits.stressLevel == "very_high":
        cardiovascular += 20
        lifestyle += 20
    elif habits.stressLevel == "high":
        cardiovascular += 10
        lifestyle += 10

    # Chronic conditions
    if "diabetes" in medical.chronicConditions:
        diabetes += 40
    if "hypertension" in medical.chronicConditions:
        cardiovascular += 30
    if "heart_disease" in medical.chronicConditions:
        cardiovascular += 40

    # Hospitalizations
    if medical.hospitalizations > 2:
        cardiovascular += 10
        lifestyle += 10

    # Family history
    if family.heartDisease:
        genetic += 25
    if family.diabetes:
        genetic += 20
        diabetes += 15
    if family.cancer:
        genetic += 15
    if family.hypertension:
        genetic += 15
        cardiovascular += 10

    # Normalize scores to 0-100
    def normalize(score: int) -> int:
        return min(100, max(0, score))

    cardiovascular = normalize(cardiovascular)
    diabetes = normalize(diabetes)
    lifestyle = normalize(lifestyle)
    genetic = normalize(genetic)

    overall = round(cardiovascular * 0.3 + diabetes * 0.25 + lifestyle * 0.25 + genetic * 0.2)
    overall = normalize(overall)

    return RiskScore(
        overall=overall,
        cardiovascular=cardiovascular,
        diabetes=diabetes,
        lifestyle=lifestyle,
        genetic=genetic
    )


def get_risk_level(score: int) -> str:
    """Determine risk level from overall score."""
    if score < 25:
        return "low"
    elif score < 50:
        return "moderate"
    elif score < 75:
        return "high"
    return "critical"


def generate_recommendations(risk_score: RiskScore, data: HealthAssessmentData) -> List[str]:
    """Generate health recommendations based on risk scores."""
    recommendations = []

    if risk_score.cardiovascular > 40:
        recommendations.append("Schedule regular cardiovascular health checkups")
        recommendations.append("Consider monitoring blood pressure at home")

    if risk_score.diabetes > 35:
        recommendations.append("Get regular blood sugar tests")
        recommendations.append("Consider consulting with a nutritionist")

    if risk_score.lifestyle > 40:
        recommendations.append("Focus on improving sleep quality and duration")
        recommendations.append("Consider stress management techniques like meditation")

    if data.lifestyleHabits.smokingStatus == "current":
        recommendations.append("Smoking cessation programs can significantly reduce health risks")

    if data.lifestyleHabits.exerciseFrequency == "sedentary":
        recommendations.append("Start with 30 minutes of walking daily")

    if data.bodyMetrics.bmi >= 25:
        recommendations.append("A balanced diet with portion control can help manage weight")

    if risk_score.genetic > 30:
        recommendations.append("Regular screenings are important given family health history")

    if len(recommendations) == 0:
        recommendations.append("Maintain your healthy lifestyle habits")
        recommendations.append("Continue regular annual health checkups")

    return recommendations[:5]


def generate_policy_recommendations(risk_score: RiskScore, partners: list) -> List[PolicyRecommendation]:
    """Generate policy recommendations based on risk score and available partners."""
    policies = []

    base_policies = [
        {
            "policyName": "Health Guard Plus",
            "coverageAmount": 1000000,
            "basePremium": 12000,
            "baseMatch": 95,
            "keyBenefits": [
                "Cashless treatment at 5000+ hospitals",
                "No room rent capping",
                "Pre & post hospitalization covered",
                "Free annual health checkup"
            ],
            "exclusions": ["Pre-existing diseases (2 year waiting)", "Cosmetic surgery"],
            "claimSettlementRatio": 96
        },
        {
            "policyName": "SecureHealth Pro",
            "coverageAmount": 750000,
            "basePremium": 9500,
            "baseMatch": 88,
            "keyBenefits": [
                "Day care procedures covered",
                "Ambulance charges included",
                "Maternity benefits available",
                "Wellness rewards program"
            ],
            "exclusions": ["Adventure sports injuries", "Self-inflicted injuries"],
            "claimSettlementRatio": 94
        },
        {
            "policyName": "MediCare Premier",
            "coverageAmount": 1500000,
            "basePremium": 18000,
            "baseMatch": 92,
            "keyBenefits": [
                "Worldwide emergency coverage",
                "Organ donor expenses covered",
                "Mental health coverage",
                "No claim bonus up to 100%"
            ],
            "exclusions": ["Dental treatment", "Experimental treatments"],
            "claimSettlementRatio": 97
        },
        {
            "policyName": "Optima Restore",
            "coverageAmount": 2000000,
            "basePremium": 22000,
            "baseMatch": 85,
            "keyBenefits": [
                "Sum insured restoration benefit",
                "Coverage for 30+ critical illnesses",
                "Air ambulance coverage",
                "Second opinion benefit"
            ],
            "exclusions": ["War-related injuries", "Hazardous activities"],
            "claimSettlementRatio": 95
        }
    ]

    active_partners = [p for p in partners if p.is_active][:4]

    for i, policy_template in enumerate(base_policies):
        if i >= len(active_partners):
            break

        partner = active_partners[i]

        # Adjust based on risk score
        match_score = max(60, policy_template["baseMatch"] - risk_score.overall // 10)
        premium = int(policy_template["basePremium"] * (1 + risk_score.overall / 200))

        policies.append(PolicyRecommendation(
            id=f"policy_{partner.id}_{i}",
            partnerId=partner.id,
            partnerName=partner.name,
            partnerLogo=partner.logo or "",
            policyName=policy_template["policyName"],
            coverageAmount=policy_template["coverageAmount"],
            premiumEstimate=premium,
            premiumFrequency="yearly",
            matchScore=match_score,
            keyBenefits=policy_template["keyBenefits"],
            exclusions=policy_template["exclusions"],
            claimSettlementRatio=policy_template["claimSettlementRatio"],
            affiliateUrl=partner.affiliate_url
        ))

    return sorted(policies, key=lambda x: x.matchScore, reverse=True)
