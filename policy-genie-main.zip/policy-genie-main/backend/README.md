# Health Insight Pro - Python Backend

A FastAPI backend for the Health Insight Pro health insurance recommendation platform.

## Features

- JWT-based authentication with password hashing
- Role-based access control (admin/user)
- Health assessment submission and risk calculation
- Insurance partner management
- Analytics tracking
- SQLite database (easily swappable to PostgreSQL)

## Setup

### 1. Create virtual environment

```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure environment

Create a `.env` file in the backend directory:

```env
SECRET_KEY=your-super-secret-key-change-in-production
DATABASE_URL=sqlite:///./health_insight.db
ADMIN_EMAIL=suhasbs9353@gmail.com
ADMIN_PASSWORD=Suhasbs1807@
```

### 4. Run the server

```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

The API will be available at `http://localhost:8000`

API documentation: `http://localhost:8000/docs`

## Connecting Frontend

Update the frontend's `src/config/api.ts`:

```typescript
export const API_BASE_URL = 'http://localhost:8000';
```

Or set the environment variable:

```
VITE_API_URL=http://localhost:8000
```

## Default Admin Account

On first run, an admin account is created with the credentials from your `.env` file.

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login and get JWT token
- `GET /api/auth/me` - Get current user info

### Assessment
- `POST /api/assessment/submit` - Submit health assessment
- `GET /api/assessment/prediction/{id}` - Get prediction by ID
- `GET /api/assessment/user-predictions` - Get user's predictions

### Partners (Admin only)
- `GET /api/partners` - List all partners
- `POST /api/partners` - Create partner
- `PUT /api/partners/{id}` - Update partner
- `DELETE /api/partners/{id}` - Delete partner

### Analytics
- `POST /api/analytics/click` - Track affiliate click
- `GET /api/analytics` - Get analytics summary (Admin only)

### Admin
- `GET /api/admin/stats` - Get admin dashboard stats
- `GET /api/admin/users` - List all users
