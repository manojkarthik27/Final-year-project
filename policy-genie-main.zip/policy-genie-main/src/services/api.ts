import { API_ENDPOINTS, getApiUrl } from '@/config/api';
import type {
  User,
  HealthAssessmentData,
  PredictionResult,
  InsurancePartner,
  PolicyRecommendation,
  AnalyticsSummary,
  ApiResponse,
} from '@/types';

// Helper function for API calls
async function fetchApi<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<ApiResponse<T>> {
  const token = localStorage.getItem('auth_token');
  
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...(token && { Authorization: `Bearer ${token}` }),
    ...options.headers,
  };

  try {
    const response = await fetch(getApiUrl(endpoint), {
      ...options,
      headers,
    });

    const data = await response.json();

    if (!response.ok) {
      return {
        success: false,
        error: data.message || data.error || 'An error occurred',
      };
    }

    return {
      success: true,
      data,
    };
  } catch (error) {
    console.error('API Error:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Network error',
    };
  }
}

// Auth API
export const authApi = {
  login: async (email: string, password: string) => {
    return fetchApi<{ user: User; token: string }>(API_ENDPOINTS.login, {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  },

  register: async (email: string, password: string, name: string) => {
    return fetchApi<{ user: User; token: string }>(API_ENDPOINTS.register, {
      method: 'POST',
      body: JSON.stringify({ email, password, name }),
    });
  },

  logout: async () => {
    return fetchApi<void>(API_ENDPOINTS.logout, { method: 'POST' });
  },

  getMe: async () => {
    return fetchApi<User>(API_ENDPOINTS.me);
  },
};

// Assessment API
export const assessmentApi = {
  submit: async (data: HealthAssessmentData) => {
    return fetchApi<PredictionResult>(API_ENDPOINTS.submitAssessment, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  getPrediction: async (id: string) => {
    return fetchApi<PredictionResult>(`${API_ENDPOINTS.getPrediction}/${id}`);
  },

  getUserPredictions: async () => {
    return fetchApi<PredictionResult[]>(API_ENDPOINTS.getUserPredictions);
  },
};

// Policy API
export const policyApi = {
  getRecommendations: async (predictionId: string) => {
    return fetchApi<PolicyRecommendation[]>(
      `${API_ENDPOINTS.getRecommendations}/${predictionId}`
    );
  },
};

// Partner API (Admin)
export const partnerApi = {
  getAll: async () => {
    return fetchApi<InsurancePartner[]>(API_ENDPOINTS.getPartners);
  },

  create: async (partner: Omit<InsurancePartner, 'id' | 'createdAt' | 'updatedAt'>) => {
    return fetchApi<InsurancePartner>(API_ENDPOINTS.createPartner, {
      method: 'POST',
      body: JSON.stringify(partner),
    });
  },

  update: async (id: string, partner: Partial<InsurancePartner>) => {
    return fetchApi<InsurancePartner>(`${API_ENDPOINTS.updatePartner}/${id}`, {
      method: 'PUT',
      body: JSON.stringify(partner),
    });
  },

  delete: async (id: string) => {
    return fetchApi<void>(`${API_ENDPOINTS.deletePartner}/${id}`, {
      method: 'DELETE',
    });
  },
};

// Analytics API
export const analyticsApi = {
  trackClick: async (partnerId: string, policyId: string, source: string) => {
    return fetchApi<void>(API_ENDPOINTS.trackClick, {
      method: 'POST',
      body: JSON.stringify({ partnerId, policyId, source }),
    });
  },

  getAnalytics: async (startDate?: string, endDate?: string) => {
    const params = new URLSearchParams();
    if (startDate) params.append('startDate', startDate);
    if (endDate) params.append('endDate', endDate);
    
    const query = params.toString();
    return fetchApi<AnalyticsSummary>(
      `${API_ENDPOINTS.getAnalytics}${query ? `?${query}` : ''}`
    );
  },
};

// Admin API
export const adminApi = {
  getStats: async () => {
    return fetchApi<AnalyticsSummary>(API_ENDPOINTS.getAdminStats);
  },

  getUsers: async () => {
    return fetchApi<User[]>(API_ENDPOINTS.getUsers);
  },
};
