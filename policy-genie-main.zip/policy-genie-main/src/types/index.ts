// User & Auth Types
export interface User {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'admin';
  createdAt: string;
  avatar?: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

// Health Assessment Types
export interface PersonalInfo {
  age: number;
  gender: 'male' | 'female' | 'other';
  location: string;
  occupation: string;
  annualIncome: number;
}

export interface BodyMetrics {
  height: number; // cm
  weight: number; // kg
  bmi: number;
}

export interface LifestyleHabits {
  smokingStatus: 'never' | 'former' | 'current';
  alcoholConsumption: 'none' | 'occasional' | 'moderate' | 'heavy';
  exerciseFrequency: 'sedentary' | 'light' | 'moderate' | 'active' | 'very_active';
  dietType: 'balanced' | 'vegetarian' | 'vegan' | 'keto' | 'poor';
  sleepHours: number;
  stressLevel: 'low' | 'moderate' | 'high' | 'very_high';
}

export interface MedicalHistory {
  chronicConditions: string[];
  previousSurgeries: string[];
  hospitalizations: number;
  currentMedications: string[];
  allergies: string[];
}

export interface FamilyHistory {
  heartDisease: boolean;
  diabetes: boolean;
  cancer: boolean;
  hypertension: boolean;
  mentalHealth: boolean;
  other: string[];
}

export interface HealthAssessmentData {
  personalInfo: PersonalInfo;
  bodyMetrics: BodyMetrics;
  lifestyleHabits: LifestyleHabits;
  medicalHistory: MedicalHistory;
  familyHistory: FamilyHistory;
}

// Risk & Prediction Types
export type RiskLevel = 'low' | 'moderate' | 'high' | 'critical';

export interface RiskScore {
  overall: number;
  cardiovascular: number;
  diabetes: number;
  lifestyle: number;
  genetic: number;
}

export interface PredictionResult {
  id: string;
  userId: string;
  assessmentData: HealthAssessmentData;
  riskScore: RiskScore;
  riskLevel: RiskLevel;
  recommendations: string[];
  createdAt: string;
  policyRecommendations: PolicyRecommendation[];
}

// Insurance Partner & Policy Types
export interface InsurancePartner {
  id: string;
  name: string;
  logo: string;
  website: string;
  affiliateUrl: string;
  affiliateCode: string;
  description: string;
  rating: number;
  isActive: boolean;
  priority: number;
  createdAt: string;
  updatedAt: string;
}

export interface PolicyRecommendation {
  id: string;
  partnerId: string;
  partnerName: string;
  partnerLogo: string;
  policyName: string;
  coverageAmount: number;
  premiumEstimate: number;
  premiumFrequency: 'monthly' | 'quarterly' | 'yearly';
  matchScore: number;
  keyBenefits: string[];
  exclusions: string[];
  claimSettlementRatio: number;
  affiliateUrl: string;
}

// Analytics Types
export interface ClickEvent {
  id: string;
  userId: string;
  partnerId: string;
  policyId: string;
  timestamp: string;
  converted: boolean;
  source: string;
}

export interface AnalyticsSummary {
  totalPredictions: number;
  totalClicks: number;
  totalConversions: number;
  conversionRate: number;
  averageRiskScore: number;
  riskDistribution: {
    low: number;
    moderate: number;
    high: number;
    critical: number;
  };
  topPartners: {
    partnerId: string;
    partnerName: string;
    clicks: number;
    conversions: number;
  }[];
  dailyStats: {
    date: string;
    predictions: number;
    clicks: number;
    conversions: number;
  }[];
}

// Form Step Types
export interface FormStep {
  id: string;
  title: string;
  description: string;
  icon: string;
}

// API Response Types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}
