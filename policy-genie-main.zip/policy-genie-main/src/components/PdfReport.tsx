import { forwardRef } from 'react';
import { Heart, Shield, CheckCircle, AlertTriangle, Phone, Mail, MapPin, Calendar, User } from 'lucide-react';
import type { PredictionResult, PolicyRecommendation } from '@/types';

interface PdfReportProps {
  prediction: PredictionResult;
  policies: PolicyRecommendation[];
  patientName?: string;
}

const PdfReport = forwardRef<HTMLDivElement, PdfReportProps>(
  ({ prediction, policies, patientName = "Patient" }, ref) => {
    const getRiskLabel = (score: number) => {
      if (score < 25) return { label: "Low", color: "#22c55e" };
      if (score < 50) return { label: "Moderate", color: "#f59e0b" };
      if (score < 75) return { label: "High", color: "#f97316" };
      return { label: "Critical", color: "#ef4444" };
    };

    const risk = getRiskLabel(prediction.riskScore.overall);
    const reportDate = new Date().toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
    const reportId = `HIP-${Date.now().toString().slice(-8)}`;

    return (
      <div 
        ref={ref} 
        className="bg-white text-black p-8 max-w-4xl mx-auto"
        style={{ fontFamily: 'Times New Roman, serif', fontSize: '12px', lineHeight: '1.6' }}
      >
        {/* Header - Like Prescription */}
        <div className="border-b-4 border-double border-blue-800 pb-4 mb-6">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-blue-800 rounded-lg flex items-center justify-center">
                <Heart className="w-10 h-10 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-blue-800" style={{ fontFamily: 'Georgia, serif' }}>
                  HEALTH INSIGHT PRO
                </h1>
                <p className="text-sm text-gray-600">Advanced Health Risk Assessment & Insurance Advisory</p>
                <p className="text-xs text-gray-500 mt-1">Licensed Healthcare Analytics Platform | Reg. No. HIPM/2024/001</p>
              </div>
            </div>
            <div className="text-right text-xs text-gray-600">
              <p className="flex items-center justify-end gap-1"><Phone className="w-3 h-3" /> +91-1800-123-4567</p>
              <p className="flex items-center justify-end gap-1"><Mail className="w-3 h-3" /> care@healthinsight.pro</p>
              <p className="flex items-center justify-end gap-1"><MapPin className="w-3 h-3" /> Mumbai, Maharashtra</p>
            </div>
          </div>
        </div>

        {/* Report Title */}
        <div className="text-center mb-6">
          <h2 className="text-xl font-bold uppercase tracking-widest text-gray-800 border-b border-gray-300 pb-2">
            COMPREHENSIVE HEALTH RISK ASSESSMENT REPORT
          </h2>
          <p className="text-sm text-gray-500 mt-2">Confidential Medical Document</p>
        </div>

        {/* Patient & Report Info */}
        <div className="grid grid-cols-2 gap-6 mb-6 border border-gray-300 p-4 rounded">
          <div>
            <h3 className="font-bold text-blue-800 border-b border-blue-200 pb-1 mb-2 flex items-center gap-2">
              <User className="w-4 h-4" /> PATIENT INFORMATION
            </h3>
            <table className="text-sm w-full">
              <tbody>
                <tr><td className="text-gray-600 pr-4">Name:</td><td className="font-semibold">{patientName}</td></tr>
                <tr><td className="text-gray-600 pr-4">Age/Gender:</td><td>{prediction.assessmentData.personalInfo.age} years / {prediction.assessmentData.personalInfo.gender}</td></tr>
                <tr><td className="text-gray-600 pr-4">Location:</td><td>{prediction.assessmentData.personalInfo.location || 'Not specified'}</td></tr>
                <tr><td className="text-gray-600 pr-4">Occupation:</td><td>{prediction.assessmentData.personalInfo.occupation || 'Not specified'}</td></tr>
              </tbody>
            </table>
          </div>
          <div>
            <h3 className="font-bold text-blue-800 border-b border-blue-200 pb-1 mb-2 flex items-center gap-2">
              <Calendar className="w-4 h-4" /> REPORT DETAILS
            </h3>
            <table className="text-sm w-full">
              <tbody>
                <tr><td className="text-gray-600 pr-4">Report ID:</td><td className="font-mono">{reportId}</td></tr>
                <tr><td className="text-gray-600 pr-4">Date:</td><td>{reportDate}</td></tr>
                <tr><td className="text-gray-600 pr-4">Assessment Date:</td><td>{new Date(prediction.createdAt).toLocaleDateString('en-IN')}</td></tr>
                <tr><td className="text-gray-600 pr-4">Valid Until:</td><td>{new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toLocaleDateString('en-IN')}</td></tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Body Metrics */}
        <div className="mb-6 border border-gray-300 p-4 rounded">
          <h3 className="font-bold text-blue-800 border-b border-blue-200 pb-1 mb-3">PHYSICAL PARAMETERS</h3>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div className="bg-gray-50 p-3 rounded">
              <p className="text-2xl font-bold text-blue-800">{prediction.assessmentData.bodyMetrics.height} cm</p>
              <p className="text-xs text-gray-600">Height</p>
            </div>
            <div className="bg-gray-50 p-3 rounded">
              <p className="text-2xl font-bold text-blue-800">{prediction.assessmentData.bodyMetrics.weight} kg</p>
              <p className="text-xs text-gray-600">Weight</p>
            </div>
            <div className="bg-gray-50 p-3 rounded">
              <p className="text-2xl font-bold text-blue-800">{prediction.assessmentData.bodyMetrics.bmi.toFixed(1)}</p>
              <p className="text-xs text-gray-600">BMI (kg/m²)</p>
            </div>
          </div>
        </div>

        {/* Risk Assessment - Main Section */}
        <div className="mb-6 border-2 border-gray-400 p-4 rounded bg-gray-50">
          <h3 className="font-bold text-blue-800 text-lg border-b-2 border-blue-800 pb-2 mb-4 text-center">
            RISK ASSESSMENT SUMMARY
          </h3>
          
          <div className="flex justify-center mb-4">
            <div 
              className="w-32 h-32 rounded-full flex items-center justify-center text-white text-3xl font-bold"
              style={{ backgroundColor: risk.color, boxShadow: `0 0 20px ${risk.color}40` }}
            >
              {prediction.riskScore.overall}%
            </div>
          </div>
          
          <div className="text-center mb-4">
            <span 
              className="px-4 py-2 rounded-full text-white font-bold text-lg"
              style={{ backgroundColor: risk.color }}
            >
              {risk.label.toUpperCase()} RISK
            </span>
          </div>

          <table className="w-full text-sm border border-gray-300">
            <thead className="bg-blue-800 text-white">
              <tr>
                <th className="p-2 text-left">Risk Category</th>
                <th className="p-2 text-center">Score</th>
                <th className="p-2 text-center">Level</th>
                <th className="p-2 text-left">Assessment</th>
              </tr>
            </thead>
            <tbody>
              {[
                { name: 'Cardiovascular Risk', score: prediction.riskScore.cardiovascular, desc: 'Heart & blood vessel health' },
                { name: 'Diabetes Risk', score: prediction.riskScore.diabetes, desc: 'Blood sugar regulation' },
                { name: 'Lifestyle Risk', score: prediction.riskScore.lifestyle, desc: 'Daily habits & wellness' },
                { name: 'Genetic Risk', score: prediction.riskScore.genetic, desc: 'Hereditary factors' },
              ].map((item, idx) => {
                const itemRisk = getRiskLabel(item.score);
                return (
                  <tr key={idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="p-2 font-medium">{item.name}</td>
                    <td className="p-2 text-center font-bold" style={{ color: itemRisk.color }}>{item.score}%</td>
                    <td className="p-2 text-center">
                      <span className="px-2 py-1 rounded text-white text-xs" style={{ backgroundColor: itemRisk.color }}>
                        {itemRisk.label}
                      </span>
                    </td>
                    <td className="p-2 text-gray-600 text-xs">{item.desc}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Medical Recommendations */}
        <div className="mb-6 border border-gray-300 p-4 rounded">
          <h3 className="font-bold text-blue-800 border-b border-blue-200 pb-1 mb-3 flex items-center gap-2">
            <CheckCircle className="w-4 h-4" /> MEDICAL RECOMMENDATIONS
          </h3>
          <div className="grid grid-cols-2 gap-2">
            {prediction.recommendations.map((rec, idx) => (
              <div key={idx} className="flex items-start gap-2 text-sm p-2 bg-green-50 rounded border-l-4 border-green-500">
                <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span>{rec}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Insurance Policy Recommendations */}
        <div className="mb-6">
          <h3 className="font-bold text-blue-800 border-b-2 border-blue-800 pb-1 mb-4 flex items-center gap-2">
            <Shield className="w-5 h-5" /> RECOMMENDED INSURANCE POLICIES
          </h3>
          <p className="text-sm text-gray-600 mb-3 italic">
            Based on your health profile, we recommend the following insurance policies:
          </p>
          
          <table className="w-full text-xs border border-gray-300">
            <thead className="bg-blue-800 text-white">
              <tr>
                <th className="p-2 text-left">Policy Name</th>
                <th className="p-2 text-left">Insurer</th>
                <th className="p-2 text-right">Coverage</th>
                <th className="p-2 text-right">Premium/Year</th>
                <th className="p-2 text-center">Match Score</th>
                <th className="p-2 text-center">Claim Ratio</th>
              </tr>
            </thead>
            <tbody>
              {policies.slice(0, 8).map((policy, idx) => (
                <tr key={idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                  <td className="p-2 font-medium">{policy.policyName}</td>
                  <td className="p-2">{policy.partnerName}</td>
                  <td className="p-2 text-right font-mono">₹{(policy.coverageAmount / 100000).toFixed(0)}L</td>
                  <td className="p-2 text-right font-mono">₹{policy.premiumEstimate.toLocaleString()}</td>
                  <td className="p-2 text-center">
                    <span 
                      className="px-2 py-1 rounded text-white text-xs"
                      style={{ backgroundColor: policy.matchScore >= 90 ? '#22c55e' : policy.matchScore >= 75 ? '#3b82f6' : '#f59e0b' }}
                    >
                      {policy.matchScore}%
                    </span>
                  </td>
                  <td className="p-2 text-center font-medium text-green-700">{policy.claimSettlementRatio}%</td>
                </tr>
              ))}
            </tbody>
          </table>
          
          {/* Policy Benefits Summary */}
          <div className="mt-4 grid grid-cols-2 gap-4">
            {policies.slice(0, 4).map((policy, idx) => (
              <div key={idx} className="border border-gray-200 rounded p-3 text-xs">
                <h4 className="font-bold text-blue-800 mb-2">{policy.policyName} - Key Benefits</h4>
                <ul className="space-y-1">
                  {policy.keyBenefits.map((benefit, bIdx) => (
                    <li key={bIdx} className="flex items-start gap-1">
                      <CheckCircle className="w-3 h-3 text-green-600 mt-0.5 flex-shrink-0" />
                      <span>{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Lifestyle Assessment */}
        <div className="mb-6 border border-gray-300 p-4 rounded">
          <h3 className="font-bold text-blue-800 border-b border-blue-200 pb-1 mb-3">LIFESTYLE ASSESSMENT</h3>
          <div className="grid grid-cols-3 gap-4 text-sm">
            <div>
              <p className="text-gray-600">Smoking Status:</p>
              <p className="font-semibold capitalize">{prediction.assessmentData.lifestyleHabits.smokingStatus.replace('_', ' ')}</p>
            </div>
            <div>
              <p className="text-gray-600">Alcohol Consumption:</p>
              <p className="font-semibold capitalize">{prediction.assessmentData.lifestyleHabits.alcoholConsumption}</p>
            </div>
            <div>
              <p className="text-gray-600">Exercise Frequency:</p>
              <p className="font-semibold capitalize">{prediction.assessmentData.lifestyleHabits.exerciseFrequency.replace('_', ' ')}</p>
            </div>
            <div>
              <p className="text-gray-600">Diet Type:</p>
              <p className="font-semibold capitalize">{prediction.assessmentData.lifestyleHabits.dietType}</p>
            </div>
            <div>
              <p className="text-gray-600">Sleep Duration:</p>
              <p className="font-semibold">{prediction.assessmentData.lifestyleHabits.sleepHours} hours/night</p>
            </div>
            <div>
              <p className="text-gray-600">Stress Level:</p>
              <p className="font-semibold capitalize">{prediction.assessmentData.lifestyleHabits.stressLevel.replace('_', ' ')}</p>
            </div>
          </div>
        </div>

        {/* Family History */}
        <div className="mb-6 border border-gray-300 p-4 rounded">
          <h3 className="font-bold text-blue-800 border-b border-blue-200 pb-1 mb-3">FAMILY MEDICAL HISTORY</h3>
          <div className="grid grid-cols-5 gap-3 text-center text-xs">
            {[
              { label: 'Heart Disease', value: prediction.assessmentData.familyHistory.heartDisease },
              { label: 'Diabetes', value: prediction.assessmentData.familyHistory.diabetes },
              { label: 'Cancer', value: prediction.assessmentData.familyHistory.cancer },
              { label: 'Hypertension', value: prediction.assessmentData.familyHistory.hypertension },
              { label: 'Mental Health', value: prediction.assessmentData.familyHistory.mentalHealth },
            ].map((item, idx) => (
              <div key={idx} className={`p-2 rounded ${item.value ? 'bg-red-100 border border-red-300' : 'bg-green-100 border border-green-300'}`}>
                <p className="font-medium">{item.label}</p>
                <p className={`font-bold ${item.value ? 'text-red-600' : 'text-green-600'}`}>
                  {item.value ? '⚠ Present' : '✓ None'}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Disclaimer */}
        <div className="border-t-2 border-gray-400 pt-4 mt-6">
          <p className="text-xs text-gray-500 text-center italic">
            <AlertTriangle className="w-3 h-3 inline mr-1" />
            This report is generated based on the information provided and AI-based risk assessment algorithms. 
            It is not a substitute for professional medical advice, diagnosis, or treatment. 
            Please consult with a qualified healthcare provider for personalized medical recommendations.
          </p>
        </div>

        {/* Signature Section */}
        <div className="flex justify-between items-end mt-8 pt-4 border-t border-gray-300">
          <div>
            <p className="text-xs text-gray-500">Generated by Health Insight Pro</p>
            <p className="text-xs text-gray-400">Report ID: {reportId}</p>
          </div>
          <div className="text-right">
            <div className="w-32 border-b border-gray-400 mb-1"></div>
            <p className="text-xs text-gray-600">Authorized Digital Signature</p>
            <p className="text-xs text-gray-500">{reportDate}</p>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-6 pt-4 border-t border-gray-200 text-center">
          <p className="text-xs text-gray-400">
            © 2024 Health Insight Pro | www.healthinsight.pro | All Rights Reserved
          </p>
        </div>
      </div>
    );
  }
);

PdfReport.displayName = 'PdfReport';

export default PdfReport;
