import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Heart, Users, BarChart3, DollarSign, LogOut, TrendingUp, MousePointerClick, Plus, Pencil, Trash2, ExternalLink } from 'lucide-react';
import { mockAnalytics, mockPartners } from '@/services/mockData';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import type { InsurancePartner } from '@/types';
import { toast } from 'sonner';

export default function Admin() {
  const { user, logout, isAuthenticated } = useAuth();
  const [partners, setPartners] = useState<InsurancePartner[]>(mockPartners);
  const [editingPartner, setEditingPartner] = useState<InsurancePartner | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newPartner, setNewPartner] = useState({
    name: '',
    website: '',
    affiliateUrl: '',
    affiliateCode: '',
    description: '',
    isActive: true,
  });

  if (!isAuthenticated || user?.role !== 'admin') {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md w-full shadow-card">
          <CardContent className="p-8 text-center">
            <Heart className="h-12 w-12 text-primary mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">Admin Access Required</h2>
            <p className="text-muted-foreground mb-6">Sign in with an admin account to access this dashboard.</p>
            <Link to="/auth">
              <Button className="bg-primary w-full">Login as Admin</Button>
            </Link>
            <p className="text-xs text-muted-foreground mt-4">
              Demo: Use an email containing "admin" to get admin access
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleAddPartner = () => {
    const partner: InsurancePartner = {
      id: Date.now().toString(),
      ...newPartner,
      logo: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=100&h=100&fit=crop',
      rating: 4.0,
      priority: partners.length + 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setPartners([...partners, partner]);
    setNewPartner({ name: '', website: '', affiliateUrl: '', affiliateCode: '', description: '', isActive: true });
    setIsDialogOpen(false);
    toast.success('Partner added successfully');
  };

  const handleTogglePartner = (id: string) => {
    setPartners(partners.map(p => p.id === id ? { ...p, isActive: !p.isActive } : p));
    toast.success('Partner status updated');
  };

  const handleDeletePartner = (id: string) => {
    setPartners(partners.filter(p => p.id !== id));
    toast.success('Partner removed');
  };

  const riskDistributionData = [
    { name: 'Low', value: mockAnalytics.riskDistribution.low, color: 'hsl(var(--success))' },
    { name: 'Moderate', value: mockAnalytics.riskDistribution.moderate, color: 'hsl(var(--warning))' },
    { name: 'High', value: mockAnalytics.riskDistribution.high, color: 'hsl(var(--accent))' },
    { name: 'Critical', value: mockAnalytics.riskDistribution.critical, color: 'hsl(var(--destructive))' },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 glass border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link to="/" className="flex items-center gap-2">
              <div className="p-2 rounded-lg bg-primary/10">
                <Heart className="h-5 w-5 text-primary" />
              </div>
            </Link>
            <span className="font-display font-bold">Admin Dashboard</span>
          </div>
          <div className="flex items-center gap-3">
            <Link to="/dashboard">
              <Button variant="outline" size="sm">User Dashboard</Button>
            </Link>
            <Button variant="ghost" size="sm" onClick={logout}>
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Stats Overview */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="shadow-card">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Predictions</CardTitle>
              <Users className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{mockAnalytics.totalPredictions.toLocaleString()}</div>
              <p className="text-xs text-success flex items-center gap-1 mt-1">
                <TrendingUp className="h-3 w-3" /> +12% from last month
              </p>
            </CardContent>
          </Card>
          <Card className="shadow-card">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Clicks</CardTitle>
              <MousePointerClick className="h-4 w-4 text-info" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{mockAnalytics.totalClicks.toLocaleString()}</div>
              <p className="text-xs text-success flex items-center gap-1 mt-1">
                <TrendingUp className="h-3 w-3" /> +8% from last month
              </p>
            </CardContent>
          </Card>
          <Card className="shadow-card">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Conversions</CardTitle>
              <BarChart3 className="h-4 w-4 text-success" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{mockAnalytics.totalConversions}</div>
              <p className="text-xs text-muted-foreground mt-1">{mockAnalytics.conversionRate}% conversion rate</p>
            </CardContent>
          </Card>
          <Card className="shadow-card">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Est. Revenue</CardTitle>
              <DollarSign className="h-4 w-4 text-warning" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">₹{(mockAnalytics.totalConversions * 150).toLocaleString()}</div>
              <p className="text-xs text-muted-foreground mt-1">₹150 avg per conversion</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="analytics" className="space-y-6">
          <TabsList>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="partners">Partners</TabsTrigger>
            <TabsTrigger value="users">User Insights</TabsTrigger>
          </TabsList>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid lg:grid-cols-3 gap-6">
              <Card className="shadow-card lg:col-span-2">
                <CardHeader>
                  <CardTitle>Daily Activity</CardTitle>
                  <CardDescription>Predictions, clicks, and conversions over the last 30 days</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={mockAnalytics.dailyStats.slice(-14)}>
                        <defs>
                          <linearGradient id="colorPredictions" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                          </linearGradient>
                          <linearGradient id="colorClicks" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="hsl(var(--info))" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="hsl(var(--info))" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                        <XAxis dataKey="date" tick={{ fontSize: 12 }} tickFormatter={(v) => new Date(v).getDate().toString()} />
                        <YAxis tick={{ fontSize: 12 }} />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: 'hsl(var(--card))', 
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '8px'
                          }} 
                        />
                        <Area type="monotone" dataKey="predictions" stroke="hsl(var(--primary))" fillOpacity={1} fill="url(#colorPredictions)" />
                        <Area type="monotone" dataKey="clicks" stroke="hsl(var(--info))" fillOpacity={1} fill="url(#colorClicks)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-card">
                <CardHeader>
                  <CardTitle>Risk Distribution</CardTitle>
                  <CardDescription>User health risk levels</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[200px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={riskDistributionData}
                          cx="50%"
                          cy="50%"
                          innerRadius={50}
                          outerRadius={80}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {riskDistributionData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="grid grid-cols-2 gap-2 mt-4">
                    {riskDistributionData.map((item) => (
                      <div key={item.name} className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                        <span className="text-sm">{item.name}: {item.value}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="shadow-card">
              <CardHeader>
                <CardTitle>Top Performing Partners</CardTitle>
                <CardDescription>Click and conversion metrics by partner</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockAnalytics.topPartners.map((partner, i) => (
                    <div key={partner.partnerId} className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                      <div className="flex items-center gap-3">
                        <span className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold">
                          {i + 1}
                        </span>
                        <span className="font-medium">{partner.partnerName}</span>
                      </div>
                      <div className="flex items-center gap-8 text-sm">
                        <div className="text-center">
                          <p className="font-medium">{partner.clicks.toLocaleString()}</p>
                          <p className="text-xs text-muted-foreground">Clicks</p>
                        </div>
                        <div className="text-center">
                          <p className="font-medium text-success">{partner.conversions}</p>
                          <p className="text-xs text-muted-foreground">Conversions</p>
                        </div>
                        <div className="text-center">
                          <p className="font-medium">{((partner.conversions / partner.clicks) * 100).toFixed(1)}%</p>
                          <p className="text-xs text-muted-foreground">Rate</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Partners Tab */}
          <TabsContent value="partners">
            <Card className="shadow-card">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Insurance Partners</CardTitle>
                  <CardDescription>Manage affiliate partners and links</CardDescription>
                </div>
                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm" className="gap-2 bg-primary">
                      <Plus className="h-4 w-4" /> Add Partner
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add New Partner</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Partner Name</Label>
                        <Input
                          id="name"
                          placeholder="e.g., PolicyBazaar"
                          value={newPartner.name}
                          onChange={(e) => setNewPartner({ ...newPartner, name: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="website">Website URL</Label>
                        <Input
                          id="website"
                          placeholder="https://example.com"
                          value={newPartner.website}
                          onChange={(e) => setNewPartner({ ...newPartner, website: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="affiliateUrl">Affiliate URL</Label>
                        <Input
                          id="affiliateUrl"
                          placeholder="https://example.com?ref=healthinsight"
                          value={newPartner.affiliateUrl}
                          onChange={(e) => setNewPartner({ ...newPartner, affiliateUrl: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="affiliateCode">Affiliate Code</Label>
                        <Input
                          id="affiliateCode"
                          placeholder="HEALTH2024"
                          value={newPartner.affiliateCode}
                          onChange={(e) => setNewPartner({ ...newPartner, affiliateCode: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="description">Description</Label>
                        <Input
                          id="description"
                          placeholder="Brief description of the partner"
                          value={newPartner.description}
                          onChange={(e) => setNewPartner({ ...newPartner, description: e.target.value })}
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                      <Button onClick={handleAddPartner} className="bg-primary">Add Partner</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {partners.map((partner) => (
                    <div key={partner.id} className="flex items-center justify-between p-4 rounded-lg border border-border">
                      <div className="flex items-center gap-4">
                        <img src={partner.logo} alt={partner.name} className="w-12 h-12 rounded-lg object-cover" />
                        <div>
                          <p className="font-medium">{partner.name}</p>
                          <p className="text-sm text-muted-foreground">{partner.description}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <a href={partner.website} target="_blank" rel="noopener noreferrer" className="text-xs text-primary flex items-center gap-1 hover:underline">
                              Visit site <ExternalLink className="h-3 w-3" />
                            </a>
                            <span className="text-xs text-muted-foreground">• Code: {partner.affiliateCode}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={partner.isActive}
                            onCheckedChange={() => handleTogglePartner(partner.id)}
                          />
                          <span className={`text-xs ${partner.isActive ? 'text-success' : 'text-muted-foreground'}`}>
                            {partner.isActive ? 'Active' : 'Inactive'}
                          </span>
                        </div>
                        <Button variant="ghost" size="sm">
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleDeletePartner(partner.id)}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users">
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle>User Prediction Insights</CardTitle>
                <CardDescription>Anonymized user health data and trends</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid sm:grid-cols-3 gap-6 mb-6">
                  <div className="text-center p-4 rounded-lg bg-muted/50">
                    <p className="text-3xl font-bold text-primary">{mockAnalytics.averageRiskScore.toFixed(1)}</p>
                    <p className="text-sm text-muted-foreground">Avg Risk Score</p>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-muted/50">
                    <p className="text-3xl font-bold text-success">{mockAnalytics.riskDistribution.low}</p>
                    <p className="text-sm text-muted-foreground">Low Risk Users</p>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-muted/50">
                    <p className="text-3xl font-bold text-destructive">{mockAnalytics.riskDistribution.critical}</p>
                    <p className="text-sm text-muted-foreground">Critical Risk Users</p>
                  </div>
                </div>
                <p className="text-center text-muted-foreground py-8">
                  Detailed user prediction history will be available when connected to your Python backend.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
