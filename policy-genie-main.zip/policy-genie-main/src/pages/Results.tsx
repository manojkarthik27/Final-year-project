import { useEffect, useState, useMemo, useRef } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { 
  Heart, ArrowLeft, Share2, Download, ExternalLink, Star, CheckCircle, AlertCircle, 
  TrendingUp, Shield, Activity, Users, X, GitCompare, SlidersHorizontal, 
  Zap, BarChart3, PieChart, Target, Sparkles, Copy, Twitter, Linkedin, FileText
} from 'lucide-react';
import { 
  ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Cell, Legend,
  AreaChart, Area, PieChart as RechartsPieChart, Pie
} from 'recharts';
import type { PredictionResult, PolicyRecommendation } from '@/types';
import { analyticsApi } from '@/services/api';
import { toast } from 'sonner';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import PdfReport from '@/components/PdfReport';
import { useAuth } from '@/hooks/useAuth';

const RiskGauge = ({ value, label, color }: { value: number; label: string; color: string }) => {
  const circumference = 2 * Math.PI * 45;
  const strokeDashoffset = circumference - (value / 100) * circumference;

  return (
    <div className="flex flex-col items-center group">
      <div className="relative w-32 h-32">
        <svg className="w-full h-full -rotate-90 drop-shadow-lg" viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="45" fill="none" strokeWidth="10" className="stroke-muted/30" />
          <circle
            cx="50"
            cy="50"
            r="45"
            fill="none"
            strokeWidth="10"
            strokeLinecap="round"
            className={`${color} drop-shadow-md transition-all duration-1000`}
            style={{
              strokeDasharray: circumference,
              strokeDashoffset,
              filter: 'drop-shadow(0 0 8px currentColor)',
            }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-3xl font-bold bg-gradient-to-r from-foreground to-foreground/80 bg-clip-text">{value}</span>
          <span className="text-xs text-muted-foreground">/ 100</span>
        </div>
      </div>
      <span className="text-sm font-medium text-muted-foreground mt-2 group-hover:text-foreground transition-colors">{label}</span>
    </div>
  );
};

interface PolicyCardProps {
  policy: PolicyRecommendation;
  onTrackClick: () => void;
  isSelected: boolean;
  onToggleSelect: () => void;
}

const PolicyCard = ({ policy, onTrackClick, isSelected, onToggleSelect }: PolicyCardProps) => (
  <Card className={`shadow-card hover-lift transition-all duration-300 overflow-hidden ${isSelected ? 'ring-2 ring-primary shadow-glow' : ''}`}>
    <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-primary/10 to-transparent rounded-bl-full" />
    <CardHeader className="pb-3 relative">
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-3">
          <Checkbox
            checked={isSelected}
            onCheckedChange={onToggleSelect}
            className="mt-1"
          />
          <div className="relative">
            <img src={policy.partnerLogo} alt={policy.partnerName} className="w-14 h-14 rounded-xl object-cover shadow-md border-2 border-background" />
            <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-success rounded-full flex items-center justify-center">
              <CheckCircle className="h-3 w-3 text-success-foreground" />
            </div>
          </div>
          <div>
            <CardTitle className="text-lg leading-tight">{policy.policyName}</CardTitle>
            <CardDescription className="flex items-center gap-1">
              <Shield className="h-3 w-3" /> {policy.partnerName}
            </CardDescription>
          </div>
        </div>
        <Badge className={`${policy.matchScore >= 90 ? 'bg-gradient-to-r from-success to-success/80' : policy.matchScore >= 75 ? 'bg-gradient-to-r from-primary to-primary/80' : 'bg-gradient-to-r from-warning to-warning/80'} text-white shrink-0 shadow-md`}>
          <Sparkles className="h-3 w-3 mr-1" /> {policy.matchScore}%
        </Badge>
      </div>
    </CardHeader>
    <CardContent className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="p-3 rounded-lg bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20">
          <p className="text-xs text-muted-foreground">Coverage</p>
          <p className="text-xl font-bold text-primary">₹{(policy.coverageAmount / 100000).toFixed(0)}L</p>
        </div>
        <div className="p-3 rounded-lg bg-gradient-to-br from-success/10 to-success/5 border border-success/20">
          <p className="text-xs text-muted-foreground">Premium</p>
          <p className="text-xl font-bold text-success">₹{policy.premiumEstimate.toLocaleString()}<span className="text-xs text-muted-foreground font-normal">/yr</span></p>
        </div>
      </div>
      <div className="flex items-center gap-2 p-2 rounded-lg bg-warning/10">
        <Star className="h-4 w-4 text-warning fill-warning" />
        <span className="text-sm font-medium">{policy.claimSettlementRatio}% Claim Settlement Ratio</span>
      </div>
      <div className="space-y-2">
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Key Benefits</p>
        <div className="space-y-1.5">
          {policy.keyBenefits.slice(0, 3).map((benefit, i) => (
            <div key={i} className="flex items-start gap-2 text-sm">
              <CheckCircle className="h-4 w-4 text-success shrink-0 mt-0.5" />
              <span className="text-muted-foreground">{benefit}</span>
            </div>
          ))}
        </div>
      </div>
      <a 
        href={policy.affiliateUrl} 
        target="_blank" 
        rel="noopener noreferrer" 
        onClick={(e) => {
          onTrackClick();
          toast.success(`Opening ${policy.partnerName} website...`);
        }}
      >
        <Button className="w-full gap-2 bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary shadow-lg hover:shadow-xl transition-all">
          <Zap className="h-4 w-4" /> Buy Now on {policy.partnerName} <ExternalLink className="h-4 w-4" />
        </Button>
      </a>
    </CardContent>
  </Card>
);

interface FiltersState {
  coverageMin: number;
  coverageMax: number;
  premiumMin: number;
  premiumMax: number;
  minRating: number;
  partners: string[];
  sortBy: 'match' | 'premium_low' | 'premium_high' | 'coverage';
}

const defaultFilters: FiltersState = {
  coverageMin: 0,
  coverageMax: 50,
  premiumMin: 0,
  premiumMax: 50000,
  minRating: 0,
  partners: [],
  sortBy: 'match',
};

export default function Results() {
  const { id } = useParams();
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedPolicies, setSelectedPolicies] = useState<string[]>([]);
  const [filters, setFilters] = useState<FiltersState>(defaultFilters);
  const [showFilters, setShowFilters] = useState(false);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);
  const pdfReportRef = useRef<HTMLDivElement>(null);
  const { user } = useAuth();

  useEffect(() => {
    const savedPredictions = JSON.parse(localStorage.getItem('predictions') || '[]');
    const found = savedPredictions.find((p: PredictionResult) => p.id === id) || savedPredictions[0];
    if (found) {
      setPrediction(found);
    }
    setLoading(false);
  }, [id]);

  const handleTrackClick = (policy: PolicyRecommendation) => {
    analyticsApi.trackClick(policy.partnerId, policy.id, 'results_page');
  };

  const togglePolicySelection = (policyId: string) => {
    setSelectedPolicies(prev => {
      if (prev.includes(policyId)) {
        return prev.filter(id => id !== policyId);
      }
      if (prev.length >= 4) {
        toast.error('You can compare up to 4 policies at a time');
        return prev;
      }
      return [...prev, policyId];
    });
  };

  const uniquePartners = useMemo(() => {
    if (!prediction) return [];
    return [...new Set(prediction.policyRecommendations.map(p => p.partnerName))];
  }, [prediction]);

  const filteredPolicies = useMemo(() => {
    if (!prediction) return [];
    
    let policies = prediction.policyRecommendations.filter(policy => {
      const coverageInLakhs = policy.coverageAmount / 100000;
      if (coverageInLakhs < filters.coverageMin || coverageInLakhs > filters.coverageMax) return false;
      if (policy.premiumEstimate < filters.premiumMin || policy.premiumEstimate > filters.premiumMax) return false;
      if (policy.claimSettlementRatio < filters.minRating * 20) return false;
      if (filters.partners.length > 0 && !filters.partners.includes(policy.partnerName)) return false;
      return true;
    });

    switch (filters.sortBy) {
      case 'premium_low':
        policies.sort((a, b) => a.premiumEstimate - b.premiumEstimate);
        break;
      case 'premium_high':
        policies.sort((a, b) => b.premiumEstimate - a.premiumEstimate);
        break;
      case 'coverage':
        policies.sort((a, b) => b.coverageAmount - a.coverageAmount);
        break;
      default:
        policies.sort((a, b) => b.matchScore - a.matchScore);
    }

    return policies;
  }, [prediction, filters]);

  const selectedPoliciesData = useMemo(() => {
    if (!prediction) return [];
    return prediction.policyRecommendations.filter(p => selectedPolicies.includes(p.id));
  }, [prediction, selectedPolicies]);

  const resetFilters = () => {
    setFilters(defaultFilters);
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'low': return 'stroke-success';
      case 'moderate': return 'stroke-warning';
      case 'high': return 'stroke-accent';
      case 'critical': return 'stroke-destructive';
      default: return 'stroke-muted-foreground';
    }
  };

  const getRiskBadgeColor = (level: string) => {
    switch (level) {
      case 'low': return 'bg-success';
      case 'moderate': return 'bg-warning';
      case 'high': return 'bg-accent';
      case 'critical': return 'bg-destructive';
      default: return 'bg-muted';
    }
  };

  const getBarColor = (value: number) => {
    if (value < 30) return 'hsl(var(--success))';
    if (value < 50) return 'hsl(var(--warning))';
    if (value < 70) return 'hsl(var(--accent))';
    return 'hsl(var(--destructive))';
  };

  // PDF Download function - Professional Medical Report Format
  const handleDownloadPdf = async () => {
    if (!pdfReportRef.current || !prediction) return;
    
    setIsGeneratingPdf(true);
    toast.loading('Generating professional health report...');
    
    try {
      const canvas = await html2canvas(pdfReportRef.current, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff',
        logging: false,
      });
      
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const imgWidth = 210;
      const pageHeight = 297;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      const reportId = `HIP-${Date.now().toString().slice(-8)}`;
      pdf.save(`Health-Assessment-Report-${reportId}.pdf`);
      toast.dismiss();
      toast.success('Professional health report downloaded!');
    } catch (error) {
      toast.dismiss();
      toast.error('Failed to generate PDF');
      console.error(error);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // Share functions
  const handleShare = async (platform: 'copy' | 'twitter' | 'linkedin' | 'whatsapp') => {
    if (!prediction) return;
    
    const shareText = `I completed a health assessment with Health Insight Pro! My risk score is ${prediction.riskScore.overall}% (${prediction.riskLevel} risk). Check out personalized policy recommendations!`;
    const shareUrl = window.location.href;
    
    switch (platform) {
      case 'copy':
        await navigator.clipboard.writeText(`${shareText}\n${shareUrl}`);
        toast.success('Link copied to clipboard!');
        break;
      case 'twitter':
        window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`, '_blank');
        break;
      case 'linkedin':
        window.open(`https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(shareUrl)}&title=Health%20Assessment%20Results&summary=${encodeURIComponent(shareText)}`, '_blank');
        break;
      case 'whatsapp':
        window.open(`https://wa.me/?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`, '_blank');
        break;
    }
  };

  // Chart data preparations
  const radarData = prediction ? [
    { subject: 'Overall', value: prediction.riskScore.overall },
    { subject: 'Cardiovascular', value: prediction.riskScore.cardiovascular },
    { subject: 'Diabetes', value: prediction.riskScore.diabetes },
    { subject: 'Lifestyle', value: prediction.riskScore.lifestyle },
    { subject: 'Genetic', value: prediction.riskScore.genetic },
  ] : [];

  const barData = prediction ? [
    { name: 'Cardiovascular', value: prediction.riskScore.cardiovascular },
    { name: 'Diabetes', value: prediction.riskScore.diabetes },
    { name: 'Lifestyle', value: prediction.riskScore.lifestyle },
    { name: 'Genetic', value: prediction.riskScore.genetic },
  ] : [];

  const policyCompareData = filteredPolicies.slice(0, 6).map(policy => ({
    name: policy.policyName.length > 12 ? policy.policyName.substring(0, 12) + '...' : policy.policyName,
    premium: policy.premiumEstimate / 1000,
    coverage: policy.coverageAmount / 100000,
    match: policy.matchScore,
  }));

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse text-center">
          <div className="relative">
            <Heart className="h-16 w-16 text-primary mx-auto mb-4 animate-pulse" />
            <div className="absolute inset-0 h-16 w-16 mx-auto rounded-full bg-primary/20 animate-ping" />
          </div>
          <p className="text-muted-foreground">Loading your results...</p>
        </div>
      </div>
    );
  }

  if (!prediction) {
    return (
      <div className="min-h-screen bg-background">
        <header className="container mx-auto px-4 py-4">
          <Link to="/" className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-primary" />
            <span className="font-display font-bold">Health Insight Pro</span>
          </Link>
        </header>
        <div className="container mx-auto px-4 py-20 text-center">
          <AlertCircle className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h1 className="text-2xl font-bold mb-2">No Results Found</h1>
          <p className="text-muted-foreground mb-6">Complete a health assessment to see your personalized results.</p>
          <Link to="/assessment">
            <Button className="bg-primary">Start Assessment</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-muted/20">
      {/* Header */}
      <header className="sticky top-0 z-50 glass border-b border-border/50 backdrop-blur-xl">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-gradient-to-br from-primary/20 to-primary/10 shadow-lg">
              <Heart className="h-5 w-5 text-primary" />
            </div>
            <span className="font-display font-bold bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text">Health Insight Pro</span>
          </Link>
          <div className="flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="gap-2 hover:bg-primary/10">
                  <Share2 className="h-4 w-4" /> Share
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => handleShare('copy')}>
                  <Copy className="h-4 w-4 mr-2" /> Copy Link
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleShare('twitter')}>
                  <Twitter className="h-4 w-4 mr-2" /> Twitter
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleShare('linkedin')}>
                  <Linkedin className="h-4 w-4 mr-2" /> LinkedIn
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleShare('whatsapp')}>
                  <Share2 className="h-4 w-4 mr-2" /> WhatsApp
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button 
              variant="outline" 
              size="sm" 
              className="gap-2 hover:bg-primary/10"
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
            >
              <Download className="h-4 w-4" /> {isGeneratingPdf ? 'Generating...' : 'PDF'}
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8" ref={reportRef}>
        {/* Risk Overview */}
        <div className="mb-8 animate-fade-in">
          <div className="flex items-center gap-2 mb-4">
            <Link to="/dashboard">
              <Button variant="ghost" size="sm" className="gap-1 hover:bg-primary/10">
                <ArrowLeft className="h-4 w-4" /> Back to Dashboard
              </Button>
            </Link>
          </div>
          
          <Card className="shadow-card overflow-hidden border-0 bg-gradient-to-br from-card via-card to-muted/20">
            <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-bl from-primary/10 via-transparent to-transparent rounded-bl-full" />
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-gradient-to-tr from-success/10 via-transparent to-transparent rounded-tr-full" />
            
            <div className="relative p-6 md:p-8">
              <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-8">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-3 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/10">
                      <Target className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h1 className="text-2xl md:text-3xl font-display font-bold">Your Health Risk Analysis</h1>
                      <p className="text-muted-foreground">Assessment from {new Date(prediction.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                    </div>
                  </div>
                  <Badge className={`${getRiskBadgeColor(prediction.riskLevel)} text-white shadow-lg`}>
                    <Sparkles className="h-3 w-3 mr-1" />
                    {prediction.riskLevel.charAt(0).toUpperCase() + prediction.riskLevel.slice(1)} Risk Level
                  </Badge>
                </div>
                <div className="flex justify-center">
                  <RiskGauge value={prediction.riskScore.overall} label="Overall Risk Score" color={getRiskColor(prediction.riskLevel)} />
                </div>
              </div>
            </div>

            <CardContent className="p-6 pt-0">
              {/* Risk Score Cards */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                {[
                  { icon: Heart, label: 'Cardiovascular', value: prediction.riskScore.cardiovascular, color: 'text-destructive', bg: 'from-destructive/10 to-destructive/5' },
                  { icon: Activity, label: 'Diabetes', value: prediction.riskScore.diabetes, color: 'text-warning', bg: 'from-warning/10 to-warning/5' },
                  { icon: TrendingUp, label: 'Lifestyle', value: prediction.riskScore.lifestyle, color: 'text-primary', bg: 'from-primary/10 to-primary/5' },
                  { icon: Users, label: 'Genetic', value: prediction.riskScore.genetic, color: 'text-info', bg: 'from-info/10 to-info/5' },
                ].map((item, idx) => (
                  <div key={idx} className={`relative overflow-hidden flex items-center gap-3 p-4 rounded-xl bg-gradient-to-br ${item.bg} border border-border/50 hover:shadow-md transition-all group`}>
                    <div className={`p-2 rounded-lg bg-background/50 ${item.color}`}>
                      <item.icon className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">{item.label}</p>
                      <p className="text-xl font-bold">{item.value}%</p>
                    </div>
                    <div className={`absolute -right-4 -bottom-4 w-16 h-16 rounded-full ${item.color} opacity-10 group-hover:scale-150 transition-transform`} />
                  </div>
                ))}
              </div>

              {/* Charts Section */}
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                {/* Radar Chart */}
                <Card className="shadow-sm border-border/50">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <PieChart className="h-5 w-5 text-primary" /> Risk Profile Radar
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={280}>
                      <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                        <PolarGrid stroke="hsl(var(--border))" />
                        <PolarAngleAxis 
                          dataKey="subject" 
                          tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }}
                        />
                        <PolarRadiusAxis 
                          angle={30} 
                          domain={[0, 100]} 
                          tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
                        />
                        <Radar
                          name="Risk Score"
                          dataKey="value"
                          stroke="hsl(var(--primary))"
                          fill="hsl(var(--primary))"
                          fillOpacity={0.3}
                          strokeWidth={2}
                        />
                      </RadarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                {/* Bar Chart */}
                <Card className="shadow-sm border-border/50">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <BarChart3 className="h-5 w-5 text-primary" /> Risk Breakdown
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={280}>
                      <BarChart data={barData} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis type="number" domain={[0, 100]} tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                        <YAxis 
                          type="category" 
                          dataKey="name" 
                          tick={{ fill: 'hsl(var(--foreground))', fontSize: 12 }} 
                          width={100}
                        />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: 'hsl(var(--card))', 
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '8px'
                          }}
                          formatter={(value: number) => [`${value}%`, 'Risk Score']}
                        />
                        <Bar dataKey="value" radius={[0, 8, 8, 0]}>
                          {barData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={getBarColor(entry.value)} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>

              {/* Policy Comparison Chart */}
              <Card className="shadow-sm border-border/50">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-primary" /> Policy Comparison Overview
                  </CardTitle>
                  <CardDescription>Complete comparison of all recommended policies</CardDescription>
                </CardHeader>
                <CardContent>
                  {/* Chart */}
                  <ResponsiveContainer width="100%" height={250}>
                    <AreaChart data={policyCompareData} margin={{ top: 10, right: 30, left: 0, bottom: 60 }}>
                      <defs>
                        <linearGradient id="colorPremium" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                        </linearGradient>
                        <linearGradient id="colorCoverage" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(var(--success))" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="hsl(var(--success))" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis 
                        dataKey="name" 
                        tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
                        angle={-45}
                        textAnchor="end"
                        height={60}
                      />
                      <YAxis tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'hsl(var(--card))', 
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px'
                        }}
                        formatter={(value: number, name: string) => {
                          if (name === 'premium') return [`₹${value}K/yr`, 'Premium'];
                          if (name === 'coverage') return [`₹${value}L`, 'Coverage'];
                          return [`${value}%`, 'Match Score'];
                        }}
                      />
                      <Legend />
                      <Area 
                        type="monotone" 
                        dataKey="premium" 
                        name="Premium (K)"
                        stroke="hsl(var(--primary))" 
                        fillOpacity={1} 
                        fill="url(#colorPremium)" 
                        strokeWidth={2}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="coverage" 
                        name="Coverage (L)"
                        stroke="hsl(var(--success))" 
                        fillOpacity={1} 
                        fill="url(#colorCoverage)" 
                        strokeWidth={2}
                      />
                    </AreaChart>
                  </ResponsiveContainer>

                  {/* Detailed Policy Comparison Table */}
                  <div className="mt-6 border rounded-lg overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-muted/50">
                          <TableHead className="font-bold">Policy Name</TableHead>
                          <TableHead className="font-bold">Insurer</TableHead>
                          <TableHead className="text-right font-bold">Coverage</TableHead>
                          <TableHead className="text-right font-bold">Premium/Year</TableHead>
                          <TableHead className="text-center font-bold">Match %</TableHead>
                          <TableHead className="text-center font-bold">Claim Ratio</TableHead>
                          <TableHead className="font-bold">Top Benefits</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredPolicies.slice(0, 10).map((policy, idx) => (
                          <TableRow key={policy.id} className={idx % 2 === 0 ? 'bg-background' : 'bg-muted/20'}>
                            <TableCell className="font-medium">{policy.policyName}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <img src={policy.partnerLogo} alt="" className="w-6 h-6 rounded" />
                                {policy.partnerName}
                              </div>
                            </TableCell>
                            <TableCell className="text-right font-mono font-bold text-primary">
                              ₹{(policy.coverageAmount / 100000).toFixed(0)}L
                            </TableCell>
                            <TableCell className="text-right font-mono">
                              ₹{policy.premiumEstimate.toLocaleString()}
                            </TableCell>
                            <TableCell className="text-center">
                              <Badge className={`${policy.matchScore >= 90 ? 'bg-success' : policy.matchScore >= 75 ? 'bg-primary' : 'bg-warning'} text-white`}>
                                {policy.matchScore}%
                              </Badge>
                            </TableCell>
                            <TableCell className="text-center font-medium text-success">
                              {policy.claimSettlementRatio}%
                            </TableCell>
                            <TableCell className="max-w-xs">
                              <div className="flex flex-wrap gap-1">
                                {policy.keyBenefits.slice(0, 2).map((b, i) => (
                                  <span key={i} className="text-xs bg-muted px-2 py-0.5 rounded-full truncate max-w-[150px]">
                                    {b}
                                  </span>
                                ))}
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </CardContent>
          </Card>
        </div>

        {/* Recommendations & Policies */}
        <Tabs defaultValue="policies" className="animate-fade-in">
          <TabsList className="mb-6 bg-muted/50 p-1">
            <TabsTrigger value="policies" className="gap-2 data-[state=active]:bg-background data-[state=active]:shadow-sm">
              <Shield className="h-4 w-4" /> Policies ({filteredPolicies.length})
            </TabsTrigger>
            <TabsTrigger value="compare" className="gap-2 data-[state=active]:bg-background data-[state=active]:shadow-sm" disabled={selectedPolicies.length < 2}>
              <GitCompare className="h-4 w-4" /> Compare ({selectedPolicies.length})
            </TabsTrigger>
            <TabsTrigger value="tips" className="gap-2 data-[state=active]:bg-background data-[state=active]:shadow-sm">
              <Heart className="h-4 w-4" /> Health Tips
            </TabsTrigger>
          </TabsList>

          <TabsContent value="policies">
            {/* Filters Bar */}
            <div className="flex flex-wrap items-center gap-3 mb-6">
              <Sheet open={showFilters} onOpenChange={setShowFilters}>
                <SheetTrigger asChild>
                  <Button variant="outline" className="gap-2 hover:bg-primary/10">
                    <SlidersHorizontal className="h-4 w-4" /> Filters
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-80">
                  <SheetHeader>
                    <SheetTitle>Filter Policies</SheetTitle>
                  </SheetHeader>
                  <div className="space-y-6 mt-6">
                    <div className="space-y-3">
                      <Label>Coverage Amount (₹ Lakhs)</Label>
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <span>₹{filters.coverageMin}L</span>
                        <span>₹{filters.coverageMax}L</span>
                      </div>
                      <Slider
                        value={[filters.coverageMin, filters.coverageMax]}
                        onValueChange={([min, max]) => setFilters(f => ({ ...f, coverageMin: min, coverageMax: max }))}
                        min={0}
                        max={50}
                        step={5}
                      />
                    </div>

                    <div className="space-y-3">
                      <Label>Premium (₹/year)</Label>
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <span>₹{filters.premiumMin.toLocaleString()}</span>
                        <span>₹{filters.premiumMax.toLocaleString()}</span>
                      </div>
                      <Slider
                        value={[filters.premiumMin, filters.premiumMax]}
                        onValueChange={([min, max]) => setFilters(f => ({ ...f, premiumMin: min, premiumMax: max }))}
                        min={0}
                        max={50000}
                        step={1000}
                      />
                    </div>

                    <div className="space-y-3">
                      <Label>Minimum Claim Settlement ({filters.minRating * 20}%+)</Label>
                      <Slider
                        value={[filters.minRating]}
                        onValueChange={([val]) => setFilters(f => ({ ...f, minRating: val }))}
                        min={0}
                        max={5}
                        step={1}
                      />
                    </div>

                    <div className="space-y-3">
                      <Label>Insurance Partners</Label>
                      <div className="space-y-2 max-h-48 overflow-y-auto">
                        {uniquePartners.map(partner => (
                          <Label key={partner} className="flex items-center gap-2 cursor-pointer">
                            <Checkbox
                              checked={filters.partners.includes(partner)}
                              onCheckedChange={(checked) => {
                                setFilters(f => ({
                                  ...f,
                                  partners: checked
                                    ? [...f.partners, partner]
                                    : f.partners.filter(p => p !== partner)
                                }));
                              }}
                            />
                            <span className="text-sm">{partner}</span>
                          </Label>
                        ))}
                      </div>
                    </div>

                    <Button onClick={resetFilters} variant="outline" className="w-full">
                      Reset Filters
                    </Button>
                  </div>
                </SheetContent>
              </Sheet>

              <Select
                value={filters.sortBy}
                onValueChange={(value: FiltersState['sortBy']) => setFilters(f => ({ ...f, sortBy: value }))}
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="match">Best Match</SelectItem>
                  <SelectItem value="premium_low">Premium: Low to High</SelectItem>
                  <SelectItem value="premium_high">Premium: High to Low</SelectItem>
                  <SelectItem value="coverage">Coverage: High to Low</SelectItem>
                </SelectContent>
              </Select>

              {filters.partners.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {filters.partners.map(partner => (
                    <Badge key={partner} variant="secondary" className="gap-1">
                      {partner}
                      <X
                        className="h-3 w-3 cursor-pointer"
                        onClick={() => setFilters(f => ({ ...f, partners: f.partners.filter(p => p !== partner) }))}
                      />
                    </Badge>
                  ))}
                </div>
              )}

              {selectedPolicies.length >= 2 && (
                <Button
                  className="ml-auto gap-2 bg-gradient-to-r from-primary to-primary/80"
                  onClick={() => {
                    const tab = document.querySelector('[value="compare"]') as HTMLButtonElement;
                    tab?.click();
                  }}
                >
                  <GitCompare className="h-4 w-4" /> Compare {selectedPolicies.length} Policies
                </Button>
              )}
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredPolicies.map((policy) => (
                <PolicyCard
                  key={policy.id}
                  policy={policy}
                  onTrackClick={() => handleTrackClick(policy)}
                  isSelected={selectedPolicies.includes(policy.id)}
                  onToggleSelect={() => togglePolicySelection(policy.id)}
                />
              ))}
            </div>

            {filteredPolicies.length === 0 && (
              <div className="text-center py-12">
                <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No policies match your filters. Try adjusting your criteria.</p>
                <Button onClick={resetFilters} variant="outline" className="mt-4">
                  Reset Filters
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="compare">
            {selectedPoliciesData.length < 2 ? (
              <Card className="shadow-card">
                <CardContent className="p-12 text-center">
                  <GitCompare className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Select at least 2 policies to compare them side by side.</p>
                </CardContent>
              </Card>
            ) : (
              <Card className="shadow-card overflow-x-auto">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <GitCompare className="h-5 w-5 text-primary" /> Policy Comparison
                  </CardTitle>
                  <CardDescription>Comparing {selectedPoliciesData.length} policies side by side</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[180px]">Feature</TableHead>
                        {selectedPoliciesData.map(policy => (
                          <TableHead key={policy.id} className="text-center min-w-[200px]">
                            <div className="flex flex-col items-center gap-2">
                              <img src={policy.partnerLogo} alt={policy.partnerName} className="w-12 h-12 rounded-xl object-cover shadow-md" />
                              <span className="font-medium">{policy.policyName}</span>
                              <span className="text-xs text-muted-foreground">{policy.partnerName}</span>
                            </div>
                          </TableHead>
                        ))}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow>
                        <TableCell className="font-medium">Match Score</TableCell>
                        {selectedPoliciesData.map(policy => (
                          <TableCell key={policy.id} className="text-center">
                            <Badge className={`${policy.matchScore >= 90 ? 'bg-success' : policy.matchScore >= 75 ? 'bg-primary' : 'bg-warning'} text-white`}>
                              {policy.matchScore}%
                            </Badge>
                          </TableCell>
                        ))}
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Coverage</TableCell>
                        {selectedPoliciesData.map(policy => (
                          <TableCell key={policy.id} className="text-center font-semibold text-primary">
                            ₹{(policy.coverageAmount / 100000).toFixed(0)} Lakhs
                          </TableCell>
                        ))}
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Annual Premium</TableCell>
                        {selectedPoliciesData.map(policy => (
                          <TableCell key={policy.id} className="text-center font-semibold text-success">
                            ₹{policy.premiumEstimate.toLocaleString()}
                          </TableCell>
                        ))}
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Claim Settlement</TableCell>
                        {selectedPoliciesData.map(policy => (
                          <TableCell key={policy.id} className="text-center">
                            <div className="flex items-center justify-center gap-1">
                              <Star className="h-4 w-4 text-warning fill-warning" />
                              {policy.claimSettlementRatio}%
                            </div>
                          </TableCell>
                        ))}
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium align-top">Key Benefits</TableCell>
                        {selectedPoliciesData.map(policy => (
                          <TableCell key={policy.id} className="text-sm">
                            <ul className="space-y-1">
                              {policy.keyBenefits.map((benefit, i) => (
                                <li key={i} className="flex items-start gap-1">
                                  <CheckCircle className="h-3 w-3 text-success shrink-0 mt-1" />
                                  <span>{benefit}</span>
                                </li>
                              ))}
                            </ul>
                          </TableCell>
                        ))}
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium align-top">Exclusions</TableCell>
                        {selectedPoliciesData.map(policy => (
                          <TableCell key={policy.id} className="text-sm text-muted-foreground">
                            <ul className="space-y-1">
                              {policy.exclusions.map((exclusion, i) => (
                                <li key={i} className="flex items-start gap-1">
                                  <X className="h-3 w-3 text-destructive shrink-0 mt-1" />
                                  <span>{exclusion}</span>
                                </li>
                              ))}
                            </ul>
                          </TableCell>
                        ))}
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Action</TableCell>
                        {selectedPoliciesData.map(policy => (
                          <TableCell key={policy.id} className="text-center">
                            <a 
                              href={policy.affiliateUrl} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              onClick={() => {
                                handleTrackClick(policy);
                                toast.success(`Opening ${policy.partnerName} website...`);
                              }}
                            >
                              <Button size="sm" className="gap-2 bg-gradient-to-r from-primary to-primary/80">
                                <Zap className="h-3 w-3" /> Buy Now <ExternalLink className="h-3 w-3" />
                              </Button>
                            </a>
                          </TableCell>
                        ))}
                      </TableRow>
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="tips">
            <Card className="shadow-card overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-success/10 to-transparent rounded-bl-full" />
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-primary" /> Personalized Health Recommendations
                </CardTitle>
                <CardDescription>Based on your health profile analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  {prediction.recommendations.map((rec, i) => (
                    <div key={i} className="flex items-start gap-4 p-4 rounded-xl bg-gradient-to-r from-success/10 to-success/5 border border-success/20 hover:shadow-md transition-all">
                      <div className="p-2 rounded-lg bg-success/20">
                        <CheckCircle className="h-5 w-5 text-success" />
                      </div>
                      <div>
                        <p className="font-medium">{rec}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Hidden PDF Report for Download */}
      <div className="fixed left-[-9999px] top-0">
        <PdfReport 
          ref={pdfReportRef} 
          prediction={prediction} 
          policies={filteredPolicies}
          patientName={user?.name || 'Patient'}
        />
      </div>
    </div>
  );
}
