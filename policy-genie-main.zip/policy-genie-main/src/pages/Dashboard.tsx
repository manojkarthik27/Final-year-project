import { Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Heart, FileText, TrendingUp, Clock, LogOut, ArrowRight, Shield, Activity, BarChart3, PieChart, Zap, Target } from 'lucide-react';
import { useEffect, useState } from 'react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, PieChart as RechartsPieChart, Pie, Cell, BarChart, Bar, Legend } from 'recharts';
import type { PredictionResult } from '@/types';

export default function Dashboard() {
  const { user, logout, isAuthenticated } = useAuth();
  const [predictions, setPredictions] = useState<PredictionResult[]>([]);

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem('predictions') || '[]');
    setPredictions(saved);
  }, []);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 flex items-center justify-center p-4">
        <Card className="max-w-md w-full shadow-card border-0">
          <CardContent className="p-8 text-center">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/10 w-fit mx-auto mb-4">
              <Heart className="h-12 w-12 text-primary" />
            </div>
            <h2 className="text-xl font-bold mb-2">Login Required</h2>
            <p className="text-muted-foreground mb-6">Sign in to view your dashboard and saved assessments.</p>
            <Link to="/auth">
              <Button className="bg-gradient-to-r from-primary to-primary/80 w-full">Login</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const getRiskBadgeColor = (level: string) => {
    switch (level) {
      case 'low': return 'bg-success/10 text-success border-success/20';
      case 'moderate': return 'bg-warning/10 text-warning border-warning/20';
      case 'high': return 'bg-accent/10 text-accent border-accent/20';
      case 'critical': return 'bg-destructive/10 text-destructive border-destructive/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  // Chart data
  const trendData = predictions.slice(0, 7).reverse().map((p, idx) => ({
    name: `#${idx + 1}`,
    overall: p.riskScore.overall,
    cardiovascular: p.riskScore.cardiovascular,
    diabetes: p.riskScore.diabetes,
  }));

  const riskDistribution = predictions.reduce((acc, p) => {
    acc[p.riskLevel] = (acc[p.riskLevel] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const pieData = [
    { name: 'Low', value: riskDistribution.low || 0, color: 'hsl(var(--success))' },
    { name: 'Moderate', value: riskDistribution.moderate || 0, color: 'hsl(var(--warning))' },
    { name: 'High', value: riskDistribution.high || 0, color: 'hsl(var(--accent))' },
    { name: 'Critical', value: riskDistribution.critical || 0, color: 'hsl(var(--destructive))' },
  ].filter(d => d.value > 0);

  const avgScores = predictions.length > 0 ? {
    overall: Math.round(predictions.reduce((a, p) => a + p.riskScore.overall, 0) / predictions.length),
    cardiovascular: Math.round(predictions.reduce((a, p) => a + p.riskScore.cardiovascular, 0) / predictions.length),
    diabetes: Math.round(predictions.reduce((a, p) => a + p.riskScore.diabetes, 0) / predictions.length),
    lifestyle: Math.round(predictions.reduce((a, p) => a + p.riskScore.lifestyle, 0) / predictions.length),
  } : null;

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-muted/20">
      {/* Header */}
      <header className="sticky top-0 z-50 glass border-b border-border/50 backdrop-blur-xl">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-gradient-to-br from-primary/20 to-primary/10 shadow-lg">
              <Heart className="h-5 w-5 text-primary" />
            </div>
            <span className="font-display font-bold">Health Insight Pro</span>
          </Link>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground hidden sm:block">Welcome, {user?.name}</span>
            {user?.role === 'admin' && (
              <Link to="/admin">
                <Button variant="outline" size="sm">Admin Panel</Button>
              </Link>
            )}
            <Button variant="ghost" size="sm" onClick={logout} className="hover:bg-destructive/10 hover:text-destructive">
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-display font-bold mb-2 flex items-center gap-3">
              <Target className="h-8 w-8 text-primary" /> Your Dashboard
            </h1>
            <p className="text-muted-foreground">Track your health assessments and insights.</p>
          </div>
          <Link to="/assessment">
            <Button className="gap-2 bg-gradient-to-r from-primary to-primary/80 shadow-lg">
              <Zap className="h-4 w-4" /> New Assessment
            </Button>
          </Link>
        </div>

        {/* Stats Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { icon: FileText, label: 'Total Assessments', value: predictions.length, color: 'text-primary', bg: 'from-primary/10 to-primary/5' },
            { icon: TrendingUp, label: 'Latest Risk Score', value: predictions.length > 0 ? predictions[0].riskScore.overall : '--', color: 'text-warning', bg: 'from-warning/10 to-warning/5' },
            { icon: Shield, label: 'Policies Viewed', value: predictions.reduce((acc, p) => acc + p.policyRecommendations.length, 0), color: 'text-success', bg: 'from-success/10 to-success/5' },
            { icon: Clock, label: 'Last Assessment', value: predictions.length > 0 ? new Date(predictions[0].createdAt).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' }) : 'Never', color: 'text-info', bg: 'from-info/10 to-info/5' },
          ].map((stat, idx) => (
            <Card key={idx} className={`shadow-card border-0 overflow-hidden bg-gradient-to-br ${stat.bg}`}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">{stat.label}</CardTitle>
                <stat.icon className={`h-5 w-5 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Charts Section */}
        {predictions.length > 0 && (
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            {/* Risk Trend Chart */}
            <Card className="shadow-card border-0">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <BarChart3 className="h-5 w-5 text-primary" /> Risk Score Trend
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <AreaChart data={trendData}>
                    <defs>
                      <linearGradient id="colorOverall" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="name" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }} />
                    <YAxis domain={[0, 100]} tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                    <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px' }} />
                    <Area type="monotone" dataKey="overall" stroke="hsl(var(--primary))" fillOpacity={1} fill="url(#colorOverall)" strokeWidth={2} />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Risk Distribution */}
            <Card className="shadow-card border-0">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <PieChart className="h-5 w-5 text-primary" /> Risk Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                {pieData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={250}>
                    <RechartsPieChart>
                      <Pie data={pieData} cx="50%" cy="50%" innerRadius={60} outerRadius={90} paddingAngle={2} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px' }} />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-[250px] flex items-center justify-center text-muted-foreground">No data yet</div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {/* Recent Assessments */}
        <Card className="shadow-card border-0">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-primary" /> Recent Assessments
              </CardTitle>
              <CardDescription>Your health assessment history</CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            {predictions.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
                <p className="text-muted-foreground mb-4">No assessments yet. Complete your first health assessment to see results here.</p>
                <Link to="/assessment">
                  <Button className="bg-gradient-to-r from-primary to-primary/80">Start Assessment</Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-4">
                {predictions.map((prediction) => (
                  <Link key={prediction.id} to={`/results/${prediction.id}`} className="flex items-center justify-between p-4 rounded-xl border border-border/50 hover:bg-muted/50 hover:shadow-md transition-all group">
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center shadow-sm">
                        <span className="text-xl font-bold text-primary">{prediction.riskScore.overall}</span>
                      </div>
                      <div>
                        <p className="font-medium">Health Assessment</p>
                        <p className="text-sm text-muted-foreground">
                          {new Date(prediction.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })} • {prediction.policyRecommendations.length} policies
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getRiskBadgeColor(prediction.riskLevel)}`}>
                        {prediction.riskLevel.charAt(0).toUpperCase() + prediction.riskLevel.slice(1)}
                      </span>
                      <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
