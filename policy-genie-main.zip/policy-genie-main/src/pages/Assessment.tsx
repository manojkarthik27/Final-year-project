import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Slider } from '@/components/ui/slider';
import { Checkbox } from '@/components/ui/checkbox';
import { Progress } from '@/components/ui/progress';
import { Heart, User, Activity, Stethoscope, Users, ArrowLeft, ArrowRight, Check, Loader2 } from 'lucide-react';
import { useHealthAssessment } from '@/hooks/useHealthAssessment';
import { toast } from 'sonner';

const steps = [
  { id: 'personal', title: 'Personal Info', icon: User, description: 'Basic details about you' },
  { id: 'body', title: 'Body Metrics', icon: Activity, description: 'Physical measurements' },
  { id: 'lifestyle', title: 'Lifestyle', icon: Heart, description: 'Daily habits and routines' },
  { id: 'medical', title: 'Medical History', icon: Stethoscope, description: 'Past health conditions' },
  { id: 'family', title: 'Family History', icon: Users, description: 'Hereditary health factors' },
];

const chronicConditions = [
  { id: 'diabetes', label: 'Diabetes' },
  { id: 'hypertension', label: 'Hypertension' },
  { id: 'heart_disease', label: 'Heart Disease' },
  { id: 'asthma', label: 'Asthma' },
  { id: 'thyroid', label: 'Thyroid Disorders' },
  { id: 'arthritis', label: 'Arthritis' },
];

export default function Assessment() {
  const navigate = useNavigate();
  const {
    currentStep,
    isSubmitting,
    personalInfo,
    bodyMetrics,
    lifestyleHabits,
    medicalHistory,
    familyHistory,
    setPersonalInfo,
    updateBodyMetrics,
    setLifestyleHabits,
    setMedicalHistory,
    setFamilyHistory,
    nextStep,
    prevStep,
    submitAssessment,
  } = useHealthAssessment();

  const progress = ((currentStep + 1) / steps.length) * 100;

  const handleSubmit = async () => {
    try {
      const result = await submitAssessment();
      toast.success('Assessment completed!');
      navigate(`/results/${result.id}`);
    } catch (error) {
      toast.error('Failed to submit assessment');
    }
  };

  const canProceed = () => {
    switch (currentStep) {
      case 0:
        return personalInfo.age > 0 && personalInfo.location && personalInfo.occupation;
      case 1:
        return bodyMetrics.height > 0 && bodyMetrics.weight > 0;
      default:
        return true;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 glass border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-primary/10">
              <Heart className="h-5 w-5 text-primary" />
            </div>
            <span className="font-display font-bold">Health Insight Pro</span>
          </Link>
          <Link to="/">
            <Button variant="ghost" size="sm">Exit</Button>
          </Link>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-3xl">
        {/* Progress */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <span className="text-sm text-muted-foreground">Step {currentStep + 1} of {steps.length}</span>
            <span className="text-sm font-medium">{Math.round(progress)}% Complete</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Step Indicators */}
        <div className="flex justify-between mb-8 overflow-x-auto pb-2">
          {steps.map((step, i) => (
            <div key={step.id} className="flex flex-col items-center min-w-[80px]">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 ${
                  i < currentStep
                    ? 'bg-success text-success-foreground'
                    : i === currentStep
                    ? 'bg-primary text-primary-foreground shadow-glow'
                    : 'bg-muted text-muted-foreground'
                }`}
              >
                {i < currentStep ? <Check className="h-5 w-5" /> : <step.icon className="h-5 w-5" />}
              </div>
              <span className={`text-xs mt-2 text-center ${i === currentStep ? 'text-foreground font-medium' : 'text-muted-foreground'}`}>
                {step.title}
              </span>
            </div>
          ))}
        </div>

        {/* Form Content */}
        <Card className="shadow-card animate-fade-in">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {(() => {
                const StepIcon = steps[currentStep].icon;
                return <StepIcon className="h-5 w-5 text-primary" />;
              })()}
              {steps[currentStep].title}
            </CardTitle>
            <CardDescription>{steps[currentStep].description}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Step 0: Personal Info */}
            {currentStep === 0 && (
              <>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="age">Age</Label>
                    <Input
                      id="age"
                      type="number"
                      placeholder="30"
                      value={personalInfo.age || ''}
                      onChange={(e) => setPersonalInfo({ ...personalInfo, age: parseInt(e.target.value) || 0 })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Gender</Label>
                    <RadioGroup
                      value={personalInfo.gender}
                      onValueChange={(value) => setPersonalInfo({ ...personalInfo, gender: value as any })}
                      className="flex gap-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="male" id="male" />
                        <Label htmlFor="male">Male</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="female" id="female" />
                        <Label htmlFor="female">Female</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="other" id="other" />
                        <Label htmlFor="other">Other</Label>
                      </div>
                    </RadioGroup>
                  </div>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="location">City/Location</Label>
                    <Input
                      id="location"
                      placeholder="Mumbai"
                      value={personalInfo.location}
                      onChange={(e) => setPersonalInfo({ ...personalInfo, location: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="occupation">Occupation</Label>
                    <Input
                      id="occupation"
                      placeholder="Software Engineer"
                      value={personalInfo.occupation}
                      onChange={(e) => setPersonalInfo({ ...personalInfo, occupation: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="income">Annual Income (₹)</Label>
                  <Input
                    id="income"
                    type="number"
                    placeholder="1000000"
                    value={personalInfo.annualIncome || ''}
                    onChange={(e) => setPersonalInfo({ ...personalInfo, annualIncome: parseInt(e.target.value) || 0 })}
                  />
                </div>
              </>
            )}

            {/* Step 1: Body Metrics */}
            {currentStep === 1 && (
              <>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="height">Height (cm)</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="170"
                      value={bodyMetrics.height || ''}
                      onChange={(e) => updateBodyMetrics({ height: parseInt(e.target.value) || 0 })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="weight">Weight (kg)</Label>
                    <Input
                      id="weight"
                      type="number"
                      placeholder="70"
                      value={bodyMetrics.weight || ''}
                      onChange={(e) => updateBodyMetrics({ weight: parseInt(e.target.value) || 0 })}
                    />
                  </div>
                </div>
                {bodyMetrics.height > 0 && bodyMetrics.weight > 0 && (
                  <div className="p-4 rounded-lg bg-muted/50 text-center animate-scale-in">
                    <p className="text-sm text-muted-foreground mb-1">Your BMI</p>
                    <p className={`text-3xl font-bold ${
                      bodyMetrics.bmi < 18.5 ? 'text-warning' :
                      bodyMetrics.bmi < 25 ? 'text-success' :
                      bodyMetrics.bmi < 30 ? 'text-warning' : 'text-destructive'
                    }`}>
                      {bodyMetrics.bmi}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {bodyMetrics.bmi < 18.5 ? 'Underweight' :
                       bodyMetrics.bmi < 25 ? 'Normal' :
                       bodyMetrics.bmi < 30 ? 'Overweight' : 'Obese'}
                    </p>
                  </div>
                )}
              </>
            )}

            {/* Step 2: Lifestyle */}
            {currentStep === 2 && (
              <>
                <div className="space-y-3">
                  <Label>Smoking Status</Label>
                  <RadioGroup
                    value={lifestyleHabits.smokingStatus}
                    onValueChange={(value) => setLifestyleHabits({ ...lifestyleHabits, smokingStatus: value as any })}
                    className="grid grid-cols-3 gap-2"
                  >
                    {['never', 'former', 'current'].map((option) => (
                      <Label key={option} htmlFor={`smoking-${option}`} className="flex items-center space-x-2 p-3 rounded-lg border cursor-pointer hover:bg-muted/50 transition-colors [&:has(:checked)]:border-primary [&:has(:checked)]:bg-primary/5">
                        <RadioGroupItem value={option} id={`smoking-${option}`} />
                        <span className="capitalize">{option}</span>
                      </Label>
                    ))}
                  </RadioGroup>
                </div>
                <div className="space-y-3">
                  <Label>Alcohol Consumption</Label>
                  <RadioGroup
                    value={lifestyleHabits.alcoholConsumption}
                    onValueChange={(value) => setLifestyleHabits({ ...lifestyleHabits, alcoholConsumption: value as any })}
                    className="grid grid-cols-2 sm:grid-cols-4 gap-2"
                  >
                    {['none', 'occasional', 'moderate', 'heavy'].map((option) => (
                      <Label key={option} htmlFor={`alcohol-${option}`} className="flex items-center space-x-2 p-3 rounded-lg border cursor-pointer hover:bg-muted/50 transition-colors [&:has(:checked)]:border-primary [&:has(:checked)]:bg-primary/5">
                        <RadioGroupItem value={option} id={`alcohol-${option}`} />
                        <span className="capitalize text-sm">{option}</span>
                      </Label>
                    ))}
                  </RadioGroup>
                </div>
                <div className="space-y-3">
                  <Label>Exercise Frequency</Label>
                  <RadioGroup
                    value={lifestyleHabits.exerciseFrequency}
                    onValueChange={(value) => setLifestyleHabits({ ...lifestyleHabits, exerciseFrequency: value as any })}
                    className="grid grid-cols-2 sm:grid-cols-3 gap-2"
                  >
                    {[
                      { value: 'sedentary', label: 'Sedentary' },
                      { value: 'light', label: 'Light' },
                      { value: 'moderate', label: 'Moderate' },
                      { value: 'active', label: 'Active' },
                      { value: 'very_active', label: 'Very Active' },
                    ].map((option) => (
                      <Label key={option.value} htmlFor={`exercise-${option.value}`} className="flex items-center space-x-2 p-3 rounded-lg border cursor-pointer hover:bg-muted/50 transition-colors [&:has(:checked)]:border-primary [&:has(:checked)]:bg-primary/5">
                        <RadioGroupItem value={option.value} id={`exercise-${option.value}`} />
                        <span className="text-sm">{option.label}</span>
                      </Label>
                    ))}
                  </RadioGroup>
                </div>
                <div className="space-y-3">
                  <Label>Sleep Hours (per night): {lifestyleHabits.sleepHours}h</Label>
                  <Slider
                    value={[lifestyleHabits.sleepHours]}
                    onValueChange={(value) => setLifestyleHabits({ ...lifestyleHabits, sleepHours: value[0] })}
                    min={4}
                    max={12}
                    step={0.5}
                    className="py-2"
                  />
                </div>
                <div className="space-y-3">
                  <Label>Stress Level</Label>
                  <RadioGroup
                    value={lifestyleHabits.stressLevel}
                    onValueChange={(value) => setLifestyleHabits({ ...lifestyleHabits, stressLevel: value as any })}
                    className="grid grid-cols-2 sm:grid-cols-4 gap-2"
                  >
                    {['low', 'moderate', 'high', 'very_high'].map((option) => (
                      <Label key={option} htmlFor={`stress-${option}`} className="flex items-center space-x-2 p-3 rounded-lg border cursor-pointer hover:bg-muted/50 transition-colors [&:has(:checked)]:border-primary [&:has(:checked)]:bg-primary/5">
                        <RadioGroupItem value={option} id={`stress-${option}`} />
                        <span className="capitalize text-sm">{option.replace('_', ' ')}</span>
                      </Label>
                    ))}
                  </RadioGroup>
                </div>
              </>
            )}

            {/* Step 3: Medical History */}
            {currentStep === 3 && (
              <>
                <div className="space-y-3">
                  <Label>Chronic Conditions (select all that apply)</Label>
                  <div className="grid grid-cols-2 gap-3">
                    {chronicConditions.map((condition) => (
                      <Label
                        key={condition.id}
                        className="flex items-center space-x-3 p-3 rounded-lg border cursor-pointer hover:bg-muted/50 transition-colors"
                      >
                        <Checkbox
                          checked={medicalHistory.chronicConditions.includes(condition.id)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setMedicalHistory({
                                ...medicalHistory,
                                chronicConditions: [...medicalHistory.chronicConditions, condition.id],
                              });
                            } else {
                              setMedicalHistory({
                                ...medicalHistory,
                                chronicConditions: medicalHistory.chronicConditions.filter((c) => c !== condition.id),
                              });
                            }
                          }}
                        />
                        <span>{condition.label}</span>
                      </Label>
                    ))}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="hospitalizations">Number of Hospitalizations (last 5 years)</Label>
                  <Input
                    id="hospitalizations"
                    type="number"
                    min="0"
                    placeholder="0"
                    value={medicalHistory.hospitalizations || ''}
                    onChange={(e) => setMedicalHistory({ ...medicalHistory, hospitalizations: parseInt(e.target.value) || 0 })}
                  />
                </div>
              </>
            )}

            {/* Step 4: Family History */}
            {currentStep === 4 && (
              <>
                <p className="text-sm text-muted-foreground">Select conditions that run in your family (parents, siblings, grandparents)</p>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { key: 'heartDisease', label: 'Heart Disease' },
                    { key: 'diabetes', label: 'Diabetes' },
                    { key: 'cancer', label: 'Cancer' },
                    { key: 'hypertension', label: 'High Blood Pressure' },
                    { key: 'mentalHealth', label: 'Mental Health Issues' },
                  ].map((condition) => (
                    <Label
                      key={condition.key}
                      className="flex items-center space-x-3 p-3 rounded-lg border cursor-pointer hover:bg-muted/50 transition-colors"
                    >
                      <Checkbox
                        checked={familyHistory[condition.key as keyof typeof familyHistory] as boolean}
                        onCheckedChange={(checked) => {
                          setFamilyHistory({
                            ...familyHistory,
                            [condition.key]: checked,
                          });
                        }}
                      />
                      <span>{condition.label}</span>
                    </Label>
                  ))}
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between mt-6">
          <Button
            variant="outline"
            onClick={prevStep}
            disabled={currentStep === 0}
            className="gap-2"
          >
            <ArrowLeft className="h-4 w-4" /> Previous
          </Button>
          {currentStep < steps.length - 1 ? (
            <Button
              onClick={nextStep}
              disabled={!canProceed()}
              className="gap-2 bg-primary hover:bg-primary/90"
            >
              Next <ArrowRight className="h-4 w-4" />
            </Button>
          ) : (
            <Button
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="gap-2 bg-primary hover:bg-primary/90"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Analyzing...
                </>
              ) : (
                <>
                  Get Results <ArrowRight className="h-4 w-4" />
                </>
              )}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
