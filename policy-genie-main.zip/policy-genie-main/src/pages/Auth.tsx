import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Heart, Loader2, ArrowLeft, Mail, KeyRound, Shield, Users } from 'lucide-react';
import { toast } from 'sonner';

type AuthMode = 'login' | 'register' | 'forgot-password' | 'reset-password' | 'admin-login';

// Admin credentials - CHANGE THESE VALUES TO SET YOUR ADMIN ACCOUNT
const ADMIN_CREDENTIALS = {
  email: 'admin@healthinsight.com',
  password: 'Admin@123'
};

export default function Auth() {
  const navigate = useNavigate();
  const { login, register, isLoading, requestPasswordReset, resetPassword } = useAuth();
  const [mode, setMode] = useState<AuthMode>('login');
  const [loginData, setLoginData] = useState({ email: '', password: '' });
  const [registerData, setRegisterData] = useState({ name: '', email: '', password: '', confirmPassword: '' });
  const [forgotEmail, setForgotEmail] = useState('');
  const [resetData, setResetData] = useState({ email: '', newPassword: '', confirmPassword: '' });
  const [adminData, setAdminData] = useState({ email: '', password: '' });

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const success = await login(loginData.email, loginData.password);
    if (success) navigate('/dashboard');
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (registerData.password !== registerData.confirmPassword) {
      return;
    }
    const success = await register(registerData.email, registerData.password, registerData.name);
    if (success) navigate('/dashboard');
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    const success = await requestPasswordReset(forgotEmail);
    if (success) {
      setResetData({ ...resetData, email: forgotEmail });
      setMode('reset-password');
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (resetData.newPassword !== resetData.confirmPassword) {
      return;
    }
    const success = await resetPassword(resetData.email, resetData.newPassword);
    if (success) {
      setMode('login');
      setLoginData({ email: resetData.email, password: '' });
    }
  };

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Verify admin credentials
    if (adminData.email === ADMIN_CREDENTIALS.email && adminData.password === ADMIN_CREDENTIALS.password) {
      // Register admin if not exists, then login
      const users = JSON.parse(localStorage.getItem('registered_users') || '[]');
      const adminExists = users.find((u: any) => u.email.toLowerCase() === ADMIN_CREDENTIALS.email.toLowerCase());
      
      if (!adminExists) {
        users.push({
          id: 'admin-001',
          email: ADMIN_CREDENTIALS.email,
          name: 'Admin User',
          password: ADMIN_CREDENTIALS.password,
          role: 'admin',
          createdAt: new Date().toISOString(),
        });
        localStorage.setItem('registered_users', JSON.stringify(users));
      }
      
      const success = await login(ADMIN_CREDENTIALS.email, ADMIN_CREDENTIALS.password);
      if (success) {
        toast.success('Welcome, Admin!');
        navigate('/admin');
      }
    } else {
      toast.error('Invalid admin credentials');
    }
  };


  // Admin Login Screen
  if (mode === 'admin-login') {
    return (
      <div className="min-h-screen bg-gradient-hero flex items-center justify-center p-4">
        <div className="w-full max-w-md animate-scale-in">
          <Link to="/" className="flex items-center justify-center gap-2 mb-8">
            <Heart className="h-8 w-8 text-primary" />
            <span className="text-xl font-display font-bold">Health Insight Pro</span>
          </Link>

          <Card className="shadow-card border-2 border-primary/20">
            <CardHeader className="bg-gradient-to-r from-primary/10 to-primary/5">
              <button 
                onClick={() => setMode('login')}
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to User Login
              </button>
              <CardTitle className="flex items-center gap-2 text-primary">
                <Shield className="h-6 w-6" />
                Admin Portal
              </CardTitle>
              <CardDescription>
                Access the administration dashboard with admin credentials.
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              
              <form onSubmit={handleAdminLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="admin-email">Admin Email</Label>
                  <Input
                    id="admin-email"
                    type="email"
                    placeholder="admin@healthinsight.com"
                    value={adminData.email}
                    onChange={(e) => setAdminData({ ...adminData, email: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="admin-password">Admin Password</Label>
                  <Input
                    id="admin-password"
                    type="password"
                    placeholder="••••••••"
                    value={adminData.password}
                    onChange={(e) => setAdminData({ ...adminData, password: e.target.value })}
                    required
                  />
                </div>
                <Button type="submit" className="w-full bg-gradient-primary" disabled={isLoading}>
                  {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : (
                    <>
                      <Shield className="h-4 w-4 mr-2" />
                      Access Admin Dashboard
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (mode === 'forgot-password') {
    return (
      <div className="min-h-screen bg-gradient-hero flex items-center justify-center p-4">
        <div className="w-full max-w-md animate-scale-in">
          <Link to="/" className="flex items-center justify-center gap-2 mb-8">
            <Heart className="h-8 w-8 text-primary" />
            <span className="text-xl font-display font-bold">Health Insight Pro</span>
          </Link>

          <Card className="shadow-card">
            <CardHeader>
              <button 
                onClick={() => setMode('login')}
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to login
              </button>
              <CardTitle className="flex items-center gap-2">
                <Mail className="h-5 w-5" />
                Forgot Password
              </CardTitle>
              <CardDescription>
                Enter your email address and we will help you reset your password.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleForgotPassword} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="forgot-email">Email Address</Label>
                  <Input
                    id="forgot-email"
                    type="email"
                    placeholder="you@example.com"
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    required
                  />
                </div>
                <Button type="submit" className="w-full bg-gradient-primary" disabled={isLoading}>
                  {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Send Reset Instructions'}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (mode === 'reset-password') {
    return (
      <div className="min-h-screen bg-gradient-hero flex items-center justify-center p-4">
        <div className="w-full max-w-md animate-scale-in">
          <Link to="/" className="flex items-center justify-center gap-2 mb-8">
            <Heart className="h-8 w-8 text-primary" />
            <span className="text-xl font-display font-bold">Health Insight Pro</span>
          </Link>

          <Card className="shadow-card">
            <CardHeader>
              <button 
                onClick={() => setMode('login')}
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to login
              </button>
              <CardTitle className="flex items-center gap-2">
                <KeyRound className="h-5 w-5" />
                Reset Password
              </CardTitle>
              <CardDescription>
                Enter your new password for {resetData.email}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleResetPassword} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="new-password">New Password</Label>
                  <Input
                    id="new-password"
                    type="password"
                    placeholder="••••••••"
                    value={resetData.newPassword}
                    onChange={(e) => setResetData({ ...resetData, newPassword: e.target.value })}
                    required
                    minLength={6}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirm-new-password">Confirm New Password</Label>
                  <Input
                    id="confirm-new-password"
                    type="password"
                    placeholder="••••••••"
                    value={resetData.confirmPassword}
                    onChange={(e) => setResetData({ ...resetData, confirmPassword: e.target.value })}
                    required
                    minLength={6}
                  />
                  {resetData.newPassword !== resetData.confirmPassword && resetData.confirmPassword && (
                    <p className="text-xs text-destructive">Passwords do not match</p>
                  )}
                </div>
                <Button 
                  type="submit" 
                  className="w-full bg-gradient-primary" 
                  disabled={isLoading || resetData.newPassword !== resetData.confirmPassword}
                >
                  {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Update Password'}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-hero flex items-center justify-center p-4">
      <div className="w-full max-w-md animate-scale-in">
        <Link to="/" className="flex items-center justify-center gap-2 mb-8">
          <Heart className="h-8 w-8 text-primary" />
          <span className="text-xl font-display font-bold">Health Insight Pro</span>
        </Link>

        <Card className="shadow-card">
          <Tabs defaultValue="login" value={mode === 'login' ? 'login' : 'register'} onValueChange={(v) => setMode(v as AuthMode)}>
            <CardHeader>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="login" className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Login
                </TabsTrigger>
                <TabsTrigger value="register">Register</TabsTrigger>
              </TabsList>
            </CardHeader>
            <CardContent>
              <TabsContent value="login">
                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="login-email">Email</Label>
                    <Input
                      id="login-email"
                      type="email"
                      placeholder="you@example.com"
                      value={loginData.email}
                      onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="login-password">Password</Label>
                      <button
                        type="button"
                        onClick={() => setMode('forgot-password')}
                        className="text-xs text-primary hover:underline"
                      >
                        Forgot password?
                      </button>
                    </div>
                    <Input
                      id="login-password"
                      type="password"
                      placeholder="••••••••"
                      value={loginData.password}
                      onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                      required
                    />
                  </div>
                  <Button type="submit" className="w-full bg-gradient-primary" disabled={isLoading}>
                    {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Sign In'}
                  </Button>
                  
                  {/* Admin Login Option */}
                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <span className="w-full border-t" />
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-card px-2 text-muted-foreground">Or</span>
                    </div>
                  </div>
                  
                  <Button 
                    type="button" 
                    variant="outline" 
                    className="w-full gap-2 border-primary/20 hover:bg-primary/5"
                    onClick={() => setMode('admin-login')}
                  >
                    <Shield className="h-4 w-4 text-primary" />
                    Admin Login
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="register">
                <form onSubmit={handleRegister} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="register-name">Full Name</Label>
                    <Input
                      id="register-name"
                      placeholder="John Doe"
                      value={registerData.name}
                      onChange={(e) => setRegisterData({ ...registerData, name: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="register-email">Email</Label>
                    <Input
                      id="register-email"
                      type="email"
                      placeholder="you@example.com"
                      value={registerData.email}
                      onChange={(e) => setRegisterData({ ...registerData, email: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="register-password">Password</Label>
                    <Input
                      id="register-password"
                      type="password"
                      placeholder="••••••••"
                      value={registerData.password}
                      onChange={(e) => setRegisterData({ ...registerData, password: e.target.value })}
                      required
                      minLength={6}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="register-confirm-password">Confirm Password</Label>
                    <Input
                      id="register-confirm-password"
                      type="password"
                      placeholder="••••••••"
                      value={registerData.confirmPassword}
                      onChange={(e) => setRegisterData({ ...registerData, confirmPassword: e.target.value })}
                      required
                      minLength={6}
                    />
                    {registerData.password !== registerData.confirmPassword && registerData.confirmPassword && (
                      <p className="text-xs text-destructive">Passwords do not match</p>
                    )}
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-primary" 
                    disabled={isLoading || registerData.password !== registerData.confirmPassword}
                  >
                    {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Create Account'}
                  </Button>
                </form>
              </TabsContent>
            </CardContent>
          </Tabs>
        </Card>
      </div>
    </div>
  );
}