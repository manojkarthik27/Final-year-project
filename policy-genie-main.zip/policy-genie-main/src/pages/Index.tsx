import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Heart, Shield, TrendingUp, Users, ArrowRight, Activity, Stethoscope, FileCheck } from 'lucide-react';

export default function Index() {
  const features = [
    { icon: Heart, title: 'Health Risk Analysis', description: 'AI-powered assessment of your health factors' },
    { icon: Shield, title: 'Policy Matching', description: 'Find the best insurance for your profile' },
    { icon: TrendingUp, title: 'Premium Calculator', description: 'Estimate costs based on your health' },
    { icon: Users, title: 'Compare Partners', description: 'Side-by-side policy comparison' },
  ];

  const stats = [
    { value: '10K+', label: 'Assessments Completed' },
    { value: '50+', label: 'Insurance Partners' },
    { value: '98%', label: 'User Satisfaction' },
    { value: '₹2Cr+', label: 'Coverage Matched' },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 glass">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-primary/10">
              <Heart className="h-6 w-6 text-primary" />
            </div>
            <span className="text-xl font-display font-bold text-foreground">Health Insight Pro</span>
          </div>
          <nav className="flex items-center gap-3">
            <Link to="/auth">
              <Button variant="ghost" size="sm">Login</Button>
            </Link>
            <Link to="/assessment">
              <Button size="sm" className="bg-primary hover:bg-primary/90 text-primary-foreground gap-1">
                Get Started <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
        <div className="container mx-auto px-4 py-20 md:py-32 relative">
          <div className="max-w-3xl mx-auto text-center animate-fade-in">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
              <Activity className="h-4 w-4" />
              AI-Powered Health Insurance Recommendations
            </div>
            <h1 className="text-4xl md:text-6xl font-display font-bold text-foreground mb-6 leading-tight">
              Find Your Perfect{' '}
              <span className="text-primary">Health Insurance</span>
              {' '}in Minutes
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Complete a quick health assessment and get personalized policy recommendations from top insurance providers matched to your unique health profile.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/assessment">
                <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2 w-full sm:w-auto px-8">
                  Start Free Assessment <ArrowRight className="h-5 w-5" />
                </Button>
              </Link>
              <Link to="/auth">
                <Button size="lg" variant="outline" className="w-full sm:w-auto px-8">
                  Sign In to Save Results
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 border-y border-border bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, i) => (
              <div key={stat.label} className="text-center animate-fade-in" style={{ animationDelay: `${i * 100}ms` }}>
                <div className="text-3xl md:text-4xl font-display font-bold text-primary mb-1">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-display font-bold text-foreground mb-4">Why Choose Health Insight Pro?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Our advanced health analysis helps you make informed decisions about your insurance coverage.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, i) => (
              <div
                key={feature.title}
                className="group bg-card rounded-xl p-6 shadow-card hover-lift animate-fade-in border border-border/50"
                style={{ animationDelay: `${i * 100}ms` }}
              >
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <feature.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">{feature.title}</h3>
                <p className="text-muted-foreground text-sm">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-display font-bold text-foreground mb-4">How It Works</h2>
            <p className="text-muted-foreground">Three simple steps to find your ideal health insurance</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {[
              { step: '1', icon: FileCheck, title: 'Complete Assessment', desc: 'Answer questions about your health, lifestyle, and family history in our guided form.' },
              { step: '2', icon: Activity, title: 'Get Risk Analysis', desc: 'Our AI analyzes your data and calculates personalized risk scores across health categories.' },
              { step: '3', icon: Stethoscope, title: 'Compare Policies', desc: 'View matched insurance policies from top providers and choose the best one for you.' },
            ].map((item, i) => (
              <div key={item.step} className="text-center animate-fade-in" style={{ animationDelay: `${i * 150}ms` }}>
                <div className="relative inline-block mb-6">
                  <div className="w-16 h-16 rounded-full bg-primary text-primary-foreground flex items-center justify-center mx-auto shadow-glow">
                    <item.icon className="h-7 w-7" />
                  </div>
                  <span className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-accent text-accent-foreground flex items-center justify-center text-sm font-bold">
                    {item.step}
                  </span>
                </div>
                <h3 className="font-semibold text-foreground mb-2 text-lg">{item.title}</h3>
                <p className="text-muted-foreground text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="bg-primary rounded-2xl p-8 md:p-12 text-center text-primary-foreground relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-primary to-primary/80" />
            <div className="relative z-10">
              <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">Ready to Find Your Perfect Policy?</h2>
              <p className="mb-8 opacity-90 max-w-xl mx-auto">
                Takes only 5 minutes. No registration required to start. Get instant recommendations.
              </p>
              <Link to="/assessment">
                <Button size="lg" variant="secondary" className="gap-2 px-8">
                  Start Free Assessment <ArrowRight className="h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-2">
              <Heart className="h-5 w-5 text-primary" />
              <span className="font-semibold">Health Insight Pro</span>
            </div>
            <p className="text-sm text-muted-foreground">© 2024 Health Insight Pro. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
