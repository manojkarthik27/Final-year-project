import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import type { User, AuthState } from '@/types';
import { authApi } from '@/services/api';
import { toast } from 'sonner';

interface StoredUser {
  id: string;
  email: string;
  name: string;
  password: string;
  role: 'user' | 'admin';
  createdAt: string;
}

interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<boolean>;
  register: (email: string, password: string, name: string) => Promise<boolean>;
  logout: () => void;
  requestPasswordReset: (email: string) => Promise<boolean>;
  resetPassword: (email: string, newPassword: string) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Set to false when your Python backend is deployed and running
// Set VITE_API_URL in Netlify environment variables to your backend URL
const USE_MOCK_AUTH = true; // Change to false when backend is deployed

// Storage key for registered users
const USERS_STORAGE_KEY = 'registered_users';

// Helper to get all registered users
const getStoredUsers = (): StoredUser[] => {
  const users = localStorage.getItem(USERS_STORAGE_KEY);
  return users ? JSON.parse(users) : [];
};

// Helper to save users
const saveStoredUsers = (users: StoredUser[]) => {
  localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
};

// Helper to find user by email
const findUserByEmail = (email: string): StoredUser | undefined => {
  const users = getStoredUsers();
  return users.find(u => u.email.toLowerCase() === email.toLowerCase());
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    isLoading: true,
  });

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    const token = localStorage.getItem('auth_token');
    if (!token) {
      setState({ user: null, isAuthenticated: false, isLoading: false });
      return;
    }

    if (USE_MOCK_AUTH) {
      const savedUser = localStorage.getItem('current_user');
      if (savedUser) {
        const user = JSON.parse(savedUser);
        setState({
          user: {
            id: user.id,
            email: user.email,
            name: user.name,
            role: user.role,
            createdAt: user.createdAt,
          },
          isAuthenticated: true,
          isLoading: false,
        });
      } else {
        setState({ user: null, isAuthenticated: false, isLoading: false });
      }
      return;
    }

    const response = await authApi.getMe();
    if (response.success && response.data) {
      setState({
        user: response.data,
        isAuthenticated: true,
        isLoading: false,
      });
    } else {
      localStorage.removeItem('auth_token');
      setState({ user: null, isAuthenticated: false, isLoading: false });
    }
  };

  const login = async (email: string, password: string): Promise<boolean> => {
    setState((prev) => ({ ...prev, isLoading: true }));

    if (USE_MOCK_AUTH) {
      await new Promise((resolve) => setTimeout(resolve, 500));

      const storedUser = findUserByEmail(email);
      
      if (!storedUser) {
        setState((prev) => ({ ...prev, isLoading: false }));
        toast.error('No account found with this email. Please register first.');
        return false;
      }

      if (storedUser.password !== password) {
        setState((prev) => ({ ...prev, isLoading: false }));
        toast.error('Incorrect password. Please try again.');
        return false;
      }

      const user: User = {
        id: storedUser.id,
        email: storedUser.email,
        name: storedUser.name,
        role: storedUser.role,
        createdAt: storedUser.createdAt,
      };

      localStorage.setItem('auth_token', 'token_' + storedUser.id);
      localStorage.setItem('current_user', JSON.stringify(storedUser));

      setState({
        user,
        isAuthenticated: true,
        isLoading: false,
      });

      toast.success('Welcome back, ' + user.name + '!');
      return true;
    }

    const response = await authApi.login(email, password);
    if (response.success && response.data) {
      localStorage.setItem('auth_token', response.data.token);
      setState({
        user: response.data.user,
        isAuthenticated: true,
        isLoading: false,
      });
      toast.success('Welcome back!');
      return true;
    }

    setState((prev) => ({ ...prev, isLoading: false }));
    toast.error(response.error || 'Login failed');
    return false;
  };

  const register = async (
    email: string,
    password: string,
    name: string
  ): Promise<boolean> => {
    setState((prev) => ({ ...prev, isLoading: true }));

    if (USE_MOCK_AUTH) {
      await new Promise((resolve) => setTimeout(resolve, 500));

      // Check if email already exists
      const existingUser = findUserByEmail(email);
      if (existingUser) {
        setState((prev) => ({ ...prev, isLoading: false }));
        toast.error('An account with this email already exists. Please login instead.');
        return false;
      }

      // Validate password
      if (password.length < 6) {
        setState((prev) => ({ ...prev, isLoading: false }));
        toast.error('Password must be at least 6 characters long.');
        return false;
      }

      const newUser: StoredUser = {
        id: Date.now().toString(),
        email: email.toLowerCase(),
        name,
        password,
        role: email.toLowerCase().includes('admin') ? 'admin' : 'user',
        createdAt: new Date().toISOString(),
      };

      // Save to storage
      const users = getStoredUsers();
      users.push(newUser);
      saveStoredUsers(users);

      const user: User = {
        id: newUser.id,
        email: newUser.email,
        name: newUser.name,
        role: newUser.role,
        createdAt: newUser.createdAt,
      };

      localStorage.setItem('auth_token', 'token_' + newUser.id);
      localStorage.setItem('current_user', JSON.stringify(newUser));

      setState({
        user,
        isAuthenticated: true,
        isLoading: false,
      });

      toast.success('Account created successfully! Welcome, ' + name + '!');
      return true;
    }

    const response = await authApi.register(email, password, name);
    if (response.success && response.data) {
      localStorage.setItem('auth_token', response.data.token);
      setState({
        user: response.data.user,
        isAuthenticated: true,
        isLoading: false,
      });
      toast.success('Account created successfully!');
      return true;
    }

    setState((prev) => ({ ...prev, isLoading: false }));
    toast.error(response.error || 'Registration failed');
    return false;
  };

  const requestPasswordReset = async (email: string): Promise<boolean> => {
    if (USE_MOCK_AUTH) {
      await new Promise((resolve) => setTimeout(resolve, 500));
      
      const user = findUserByEmail(email);
      if (!user) {
        toast.error('No account found with this email address.');
        return false;
      }

      // In a real app, this would send an email
      // For demo, we'll just confirm the email exists
      toast.success('Password reset instructions sent to your email!');
      return true;
    }

    // Backend API call would go here
    toast.error('Password reset requires backend integration.');
    return false;
  };

  const resetPassword = async (email: string, newPassword: string): Promise<boolean> => {
    if (USE_MOCK_AUTH) {
      await new Promise((resolve) => setTimeout(resolve, 500));

      if (newPassword.length < 6) {
        toast.error('Password must be at least 6 characters long.');
        return false;
      }

      const users = getStoredUsers();
      const userIndex = users.findIndex(u => u.email.toLowerCase() === email.toLowerCase());
      
      if (userIndex === -1) {
        toast.error('No account found with this email address.');
        return false;
      }

      users[userIndex].password = newPassword;
      saveStoredUsers(users);

      toast.success('Password updated successfully! You can now login with your new password.');
      return true;
    }

    // Backend API call would go here
    toast.error('Password reset requires backend integration.');
    return false;
  };

  const logout = () => {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('current_user');
    setState({ user: null, isAuthenticated: false, isLoading: false });
    toast.success('Logged out successfully');
  };

  return (
    <AuthContext.Provider value={{ ...state, login, register, logout, requestPasswordReset, resetPassword }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}