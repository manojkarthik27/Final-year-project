import { useState, useCallback } from 'react';
import type {
  HealthAssessmentData,
  PersonalInfo,
  BodyMetrics,
  LifestyleHabits,
  MedicalHistory,
  FamilyHistory,
  PredictionResult,
  RiskScore,
  RiskLevel,
} from '@/types';
import { generateMockPolicies } from '@/services/mockData';

const initialPersonalInfo: PersonalInfo = {
  age: 30,
  gender: 'male',
  location: '',
  occupation: '',
  annualIncome: 0,
};

const initialBodyMetrics: BodyMetrics = {
  height: 170,
  weight: 70,
  bmi: 24.2,
};

const initialLifestyleHabits: LifestyleHabits = {
  smokingStatus: 'never',
  alcoholConsumption: 'none',
  exerciseFrequency: 'moderate',
  dietType: 'balanced',
  sleepHours: 7,
  stressLevel: 'moderate',
};

const initialMedicalHistory: MedicalHistory = {
  chronicConditions: [],
  previousSurgeries: [],
  hospitalizations: 0,
  currentMedications: [],
  allergies: [],
};

const initialFamilyHistory: FamilyHistory = {
  heartDisease: false,
  diabetes: false,
  cancer: false,
  hypertension: false,
  mentalHealth: false,
  other: [],
};

export function useHealthAssessment() {
  const [currentStep, setCurrentStep] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);

  const [personalInfo, setPersonalInfo] = useState<PersonalInfo>(initialPersonalInfo);
  const [bodyMetrics, setBodyMetrics] = useState<BodyMetrics>(initialBodyMetrics);
  const [lifestyleHabits, setLifestyleHabits] = useState<LifestyleHabits>(initialLifestyleHabits);
  const [medicalHistory, setMedicalHistory] = useState<MedicalHistory>(initialMedicalHistory);
  const [familyHistory, setFamilyHistory] = useState<FamilyHistory>(initialFamilyHistory);

  const calculateBMI = useCallback((height: number, weight: number): number => {
    const heightInMeters = height / 100;
    return Math.round((weight / (heightInMeters * heightInMeters)) * 10) / 10;
  }, []);

  const updateBodyMetrics = useCallback(
    (updates: Partial<BodyMetrics>) => {
      setBodyMetrics((prev) => {
        const updated = { ...prev, ...updates };
        if (updates.height !== undefined || updates.weight !== undefined) {
          updated.bmi = calculateBMI(updated.height, updated.weight);
        }
        return updated;
      });
    },
    [calculateBMI]
  );

  // Rule-based risk calculation (client-side ML simulation)
  const calculateRiskScore = useCallback((): RiskScore => {
    let cardiovascular = 0;
    let diabetes = 0;
    let lifestyle = 0;
    let genetic = 0;

    // Age factor
    if (personalInfo.age > 50) cardiovascular += 20;
    else if (personalInfo.age > 40) cardiovascular += 10;
    
    if (personalInfo.age > 45) diabetes += 15;

    // BMI factor
    if (bodyMetrics.bmi >= 30) {
      cardiovascular += 25;
      diabetes += 30;
      lifestyle += 20;
    } else if (bodyMetrics.bmi >= 25) {
      cardiovascular += 15;
      diabetes += 20;
      lifestyle += 10;
    } else if (bodyMetrics.bmi < 18.5) {
      lifestyle += 15;
    }

    // Smoking factor
    if (lifestyleHabits.smokingStatus === 'current') {
      cardiovascular += 30;
      lifestyle += 25;
    } else if (lifestyleHabits.smokingStatus === 'former') {
      cardiovascular += 10;
      lifestyle += 5;
    }

    // Alcohol factor
    if (lifestyleHabits.alcoholConsumption === 'heavy') {
      lifestyle += 25;
      cardiovascular += 15;
    } else if (lifestyleHabits.alcoholConsumption === 'moderate') {
      lifestyle += 10;
    }

    // Exercise factor
    if (lifestyleHabits.exerciseFrequency === 'sedentary') {
      cardiovascular += 20;
      diabetes += 15;
      lifestyle += 20;
    } else if (lifestyleHabits.exerciseFrequency === 'active' || lifestyleHabits.exerciseFrequency === 'very_active') {
      cardiovascular -= 10;
      diabetes -= 10;
      lifestyle -= 10;
    }

    // Sleep factor
    if (lifestyleHabits.sleepHours < 6 || lifestyleHabits.sleepHours > 9) {
      lifestyle += 15;
      cardiovascular += 10;
    }

    // Stress factor
    if (lifestyleHabits.stressLevel === 'very_high') {
      cardiovascular += 20;
      lifestyle += 20;
    } else if (lifestyleHabits.stressLevel === 'high') {
      cardiovascular += 10;
      lifestyle += 10;
    }

    // Chronic conditions
    if (medicalHistory.chronicConditions.length > 0) {
      if (medicalHistory.chronicConditions.includes('diabetes')) diabetes += 40;
      if (medicalHistory.chronicConditions.includes('hypertension')) cardiovascular += 30;
      if (medicalHistory.chronicConditions.includes('heart_disease')) cardiovascular += 40;
    }

    // Hospitalizations
    if (medicalHistory.hospitalizations > 2) {
      cardiovascular += 10;
      lifestyle += 10;
    }

    // Family history
    if (familyHistory.heartDisease) genetic += 25;
    if (familyHistory.diabetes) {
      genetic += 20;
      diabetes += 15;
    }
    if (familyHistory.cancer) genetic += 15;
    if (familyHistory.hypertension) {
      genetic += 15;
      cardiovascular += 10;
    }

    // Normalize scores to 0-100
    const normalize = (score: number) => Math.min(100, Math.max(0, score));

    cardiovascular = normalize(cardiovascular);
    diabetes = normalize(diabetes);
    lifestyle = normalize(lifestyle);
    genetic = normalize(genetic);

    const overall = Math.round(
      cardiovascular * 0.3 + diabetes * 0.25 + lifestyle * 0.25 + genetic * 0.2
    );

    return {
      overall: normalize(overall),
      cardiovascular,
      diabetes,
      lifestyle,
      genetic,
    };
  }, [personalInfo, bodyMetrics, lifestyleHabits, medicalHistory, familyHistory]);

  const getRiskLevel = (score: number): RiskLevel => {
    if (score < 25) return 'low';
    if (score < 50) return 'moderate';
    if (score < 75) return 'high';
    return 'critical';
  };

  const generateRecommendations = (riskScore: RiskScore): string[] => {
    const recommendations: string[] = [];

    if (riskScore.cardiovascular > 40) {
      recommendations.push('Schedule regular cardiovascular health checkups');
      recommendations.push('Consider monitoring blood pressure at home');
    }

    if (riskScore.diabetes > 35) {
      recommendations.push('Get regular blood sugar tests');
      recommendations.push('Consider consulting with a nutritionist');
    }

    if (riskScore.lifestyle > 40) {
      recommendations.push('Focus on improving sleep quality and duration');
      recommendations.push('Consider stress management techniques like meditation');
    }

    if (lifestyleHabits.smokingStatus === 'current') {
      recommendations.push('Smoking cessation programs can significantly reduce health risks');
    }

    if (lifestyleHabits.exerciseFrequency === 'sedentary') {
      recommendations.push('Start with 30 minutes of walking daily');
    }

    if (bodyMetrics.bmi >= 25) {
      recommendations.push('A balanced diet with portion control can help manage weight');
    }

    if (riskScore.genetic > 30) {
      recommendations.push('Regular screenings are important given family health history');
    }

    if (recommendations.length === 0) {
      recommendations.push('Maintain your healthy lifestyle habits');
      recommendations.push('Continue regular annual health checkups');
    }

    return recommendations.slice(0, 5);
  };

  const submitAssessment = useCallback(async (): Promise<PredictionResult> => {
    setIsSubmitting(true);

    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1500));

    const assessmentData: HealthAssessmentData = {
      personalInfo,
      bodyMetrics,
      lifestyleHabits,
      medicalHistory,
      familyHistory,
    };

    const riskScore = calculateRiskScore();
    const riskLevel = getRiskLevel(riskScore.overall);
    const recommendations = generateRecommendations(riskScore);
    const policyRecommendations = generateMockPolicies(riskScore);

    const result: PredictionResult = {
      id: Date.now().toString(),
      userId: localStorage.getItem('mock_user')
        ? JSON.parse(localStorage.getItem('mock_user')!).id
        : 'guest',
      assessmentData,
      riskScore,
      riskLevel,
      recommendations,
      createdAt: new Date().toISOString(),
      policyRecommendations,
    };

    // Save to localStorage for persistence
    const savedPredictions = JSON.parse(
      localStorage.getItem('predictions') || '[]'
    );
    savedPredictions.unshift(result);
    localStorage.setItem('predictions', JSON.stringify(savedPredictions.slice(0, 10)));

    setPrediction(result);
    setIsSubmitting(false);

    return result;
  }, [personalInfo, bodyMetrics, lifestyleHabits, medicalHistory, familyHistory, calculateRiskScore]);

  const resetAssessment = useCallback(() => {
    setCurrentStep(0);
    setPersonalInfo(initialPersonalInfo);
    setBodyMetrics(initialBodyMetrics);
    setLifestyleHabits(initialLifestyleHabits);
    setMedicalHistory(initialMedicalHistory);
    setFamilyHistory(initialFamilyHistory);
    setPrediction(null);
  }, []);

  const nextStep = useCallback(() => {
    setCurrentStep((prev) => Math.min(prev + 1, 4));
  }, []);

  const prevStep = useCallback(() => {
    setCurrentStep((prev) => Math.max(prev - 1, 0));
  }, []);

  const goToStep = useCallback((step: number) => {
    if (step >= 0 && step <= 4) {
      setCurrentStep(step);
    }
  }, []);

  return {
    currentStep,
    isSubmitting,
    prediction,
    personalInfo,
    bodyMetrics,
    lifestyleHabits,
    medicalHistory,
    familyHistory,
    setPersonalInfo,
    updateBodyMetrics,
    setLifestyleHabits,
    setMedicalHistory,
    setFamilyHistory,
    nextStep,
    prevStep,
    goToStep,
    submitAssessment,
    resetAssessment,
  };
}
