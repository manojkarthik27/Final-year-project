// API Configuration for Python Backend
// 
// For Netlify deployment:
// 1. Deploy your Python backend to Railway/Render/Fly.io
// 2. Set VITE_API_URL in Netlify Environment Variables to your backend URL
//    Example: https://your-backend.railway.app
//
// The frontend will use localStorage for auth until USE_MOCK_AUTH is set to false in useAuth.tsx

export const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';
export const API_ENDPOINTS = {
  // Auth
  login: '/api/auth/login',
  register: '/api/auth/register',
  logout: '/api/auth/logout',
  me: '/api/auth/me',
  
  // Health Assessment
  submitAssessment: '/api/assessment/submit',
  getPrediction: '/api/assessment/prediction',
  getUserPredictions: '/api/assessment/user-predictions',
  
  // Policies
  getPolicies: '/api/policies',
  getRecommendations: '/api/policies/recommendations',
  
  // Partners
  getPartners: '/api/partners',
  createPartner: '/api/partners',
  updatePartner: '/api/partners',
  deletePartner: '/api/partners',
  
  // Analytics
  trackClick: '/api/analytics/click',
  getAnalytics: '/api/analytics',
  getUserAnalytics: '/api/analytics/user',
  
  // Admin
  getAdminStats: '/api/admin/stats',
  getUsers: '/api/admin/users',
};

export const getApiUrl = (endpoint: string): string => {
  return `${API_BASE_URL}${endpoint}`;
};
